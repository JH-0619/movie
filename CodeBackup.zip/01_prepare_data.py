"""
01 · 데이터 정제
  A) KMDb+KOBIS 통합본 → 2015~2024 국내 극장용 장편 극영화 537편
  B) 기본데이터_공유시트 → 제작비 / 손익분기점 파싱 후 결측 제거
"""
import re
import numpy as np
import pandas as pd
from config import MAIN_XLSX, BUDGET_XLSX, DATA

# ══ A. 메인 데이터 ═══════════════════════════════════════
df = pd.read_excel(MAIN_XLSX, sheet_name="KMDb_KOBIS")


def to_num(s):
    """'1,978' 같은 콤마 숫자 문자열 → float"""
    if pd.isna(s):
        return np.nan
    if isinstance(s, (int, float)):
        return float(s)
    return float(str(s).replace(',', ''))


for c in ['전국매출액', '전국관객수', '전국스크린수']:
    df[c] = df[c].apply(to_num)

df['개봉일_dt'] = pd.to_datetime(df['개봉일'].astype(str), format='%Y%m%d', errors='coerce')
df['개봉연도'] = df['개봉일_dt'].dt.year
df['개봉월'] = df['개봉일_dt'].dt.month
df.to_pickle(f"{DATA}/raw.pkl")            # 688편 원본(변수 자료형/결측률 슬라이드용)

# 필터 3단계
n0 = len(df)
f = df[(df['개봉연도'] >= 2015) & (df['개봉연도'] <= 2024)]
n1 = len(f)
f = f[f['영화유형'] == '극영화']
n2 = len(f)
f = f[f['용도'] == '극장용'].copy()
n3 = len(f)

# 복합 장르는 첫 번째 장르를 대표 장르로 사용
f['주장르'] = f['장르'].apply(lambda x: str(x).split(',')[0].strip())
f.to_pickle(f"{DATA}/main.pkl")

print(f"[A] 원본 {n0}편")
print(f"    기간 외 제외      -{n0-n1}편")
print(f"    비장편 제외       -{n1-n2}편")
print(f"    비극장용 제외     -{n2-n3}편")
print(f"    최종 분석 대상     {n3}편")

# ══ B. 제작비 · 손익분기점 ════════════════════════════════
bd = pd.read_excel(BUDGET_XLSX, sheet_name="시트1")
bd.columns = [c.replace("\n", "") for c in bd.columns]


def parse_won(s):
    """'200억' '270억원' '130~150억원'(→중간값) → 원 단위 float"""
    if pd.isna(s):
        return np.nan
    t = str(s).replace(",", "").replace(" ", "")
    hits = re.findall(r'(\d+(?:\.\d+)?)\s*억', t)
    if hits:
        return float(np.mean([float(x) for x in hits])) * 1e8
    plain = re.findall(r'(\d+(?:\.\d+)?)', t)      # 'na' 등은 여기서도 걸러짐
    return float(plain[0]) * 1e8 if plain else np.nan


def parse_people(s):
    """'600만' '180만명' → 명 단위 float"""
    if pd.isna(s):
        return np.nan
    t = str(s).replace(",", "").replace(" ", "")
    hits = re.findall(r'(\d+(?:\.\d+)?)\s*만', t)
    if hits:
        return float(np.mean([float(x) for x in hits])) * 1e4
    plain = re.findall(r'(\d+)', t)
    return float(plain[0]) if plain else np.nan


bd['개봉일'] = pd.to_datetime(bd['개봉일'], errors='coerce')
bd['연도'] = bd['개봉일'].dt.year
bd['총제작비'] = bd['총제작'].apply(parse_won)
bd['BEP관객'] = bd['손익분기점(명)'].apply(parse_people)

fb = bd[(bd['연도'] >= 2015) & (bd['연도'] <= 2024) & (bd['영화형태'] == '장편')]
fb = fb[fb['영화명'] != '데자뷰'].copy()      # 외화 달러 환산 1건 제외
fb.to_pickle(f"{DATA}/budget.pkl")

nb = fb['총제작비'].notna().sum()
ne = fb['BEP관객'].notna().sum()
print(f"\n[B] 2015~2024 장편 {len(fb)}편")
print(f"    제작비 확보       {nb}편 ({nb/len(fb)*100:.1f}%)")
print(f"    손익분기점 확보    {ne}편 ({ne/len(fb)*100:.1f}%)")
print(f"    둘 다 확보        {(fb['총제작비'].notna() & fb['BEP관객'].notna()).sum()}편")

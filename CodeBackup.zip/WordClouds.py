import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
# import koreanize_matplotlib
import seaborn as sns

from wordcloud import WordCloud

df = pd.read_csv("movies_url.csv", encoding="utf-8-sig")

# 세 번째 컬럼(리뷰)만 추출
text = " ".join(df.iloc[:, 2].fillna("").astype(str))

wc = WordCloud(
    width=800,
    height=800,
    background_color="white",
    font_path="C:/Windows/Fonts/malgun.ttf"   # Windows
).generate(text)

plt.figure(figsize=(10,10))
plt.imshow(wc, interpolation="bilinear")
plt.axis("off")
plt.show()
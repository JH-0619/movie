# -*- coding: utf-8 -*-
"""
네이버 영화 관람평 크롤러 v4.1 — v4 + 저위험 속도 튜닝

v4 → v4.1 변경 사항 (수집 로직은 동일, 대기 방식만 최적화)
--------------------------------------------------------
1. 고정 sleep → 조건부 대기: 스크롤 후 0.8초를 무조건 기다리는 대신,
   목록의 아이템 수/높이가 변하는 순간 즉시 다음 점프 (최대 POLL_TIMEOUT까지만 대기)
2. page_load_strategy = "eager": DOM 준비 시점에 진행 (이미지·광고 로딩 안 기다림)
3. 이미지 로딩 차단: 텍스트 수집에 이미지는 불필요 (BLOCK_IMAGES로 켜고 끔)
4. 무변화 한계 8회 -> 5회 (조건부 대기 도입으로 1회당 대기 상한이 명확해져 안전)
5. 안정화 sleep 소폭 축소 (1.0 -> 0.5~0.8)

* 수집 개수가 v4보다 적게 나오면: POLL_TIMEOUT을 1.5로, NO_CHANGE_LIMIT을 8로 되돌릴 것.
* 예상 소요: 전체 799편 기준 약 2~2.5시간 (v4는 4~5시간)

v3 → v4 변경 사항 (2차 진단 naver_diag2 결과 기반)
------------------------------------------------
[문제] "영화 터널" 검색 시 2016 한국영화가 아닌 2025 외국영화 패널이 잡히는 등,
       동명 영화가 있으면 엉뚱한 영화의 관람평을 조용히 수집할 수 있음.

[진단으로 확인된 사실]
1. 정보 패널 상단 sub_title에 연도가 있음 (단, 일부 영화는 연도 표기가 없음 — 예: 베테랑)
2. "한국영화 {제목}" 검색은 연도를 항상 정확히 보여주지만,
   동명 외국영화가 있을 때만 관람평 탭이 있는 완전한 패널이 뜨고,
   그 외에는 관람평 탭이 없는 축약 패널이 뜸.
3. 축약 패널에도 해당 영화 고유번호(os=)가 담긴 링크가 있음
   → os로 관람평 페이지 URL을 직접 만들어 이동할 수 있음.
4. "영화 {제목} {연도}" 검색은 패널 자체가 안 뜸 (사용 불가).

[v4 동작 방식 — 전 영화 연도 검증]
  1차: "영화 {제목}" 검색 → 패널 연도가 엑셀의 개봉연도/제작연도 중 하나와 일치하면
       관람평 탭 클릭 → 수집  (대부분의 영화가 여기서 끝남)
  2차(1차 불일치/연도없음 시): "한국영화 {제목}" 검색 → 연도 일치 확인 후
       관람평 탭이 있으면 클릭, 없으면 패널의 os로 관람평 URL 직접 이동 → 수집
  3차(2차도 실패 시): "영화 {제목} {감독}" 검색 → 같은 방식
  모두 실패: 수집하지 않고 상태만 기록 (틀린 영화를 긁는 것보다 빈 칸이 낫다)

[중복 제목 대응]
  엑셀에 같은 제목의 다른 영화가 8쌍 존재 (마녀 2014/2018, 보호자 2013/2023 등).
  → 모든 처리를 (제목, 개봉연도) 쌍 기준으로 하고, 결과에 개봉연도/상태 컬럼 추가.
  → 같은 제목이라도 연도가 다르면 각각 검증·수집을 시도.
  (v2에는 실행 중 완료 목록이 갱신되지 않아 중복 제목이 두 번 수집되는 버그도 있었음 → 수정)

[출력 형식 변경]
  컬럼: 제목, 개봉연도, URL, 리뷰, 상태
  상태 예: ok(V1) / ok(V2직접) / 연도불일치(V1:2025,V2:2018) / 관람평없음 / ...
  → 분석 시에는 상태가 'ok'로 시작하는 행만 쓰면 됨.

사용 방법
--------
1) TEST_MODE = True 로 실행 → movies_review_naver_v4_TEST.csv 확인
   (정상/오검색/연도없음/중복제목 케이스가 모두 포함된 9편)
2) 문제 없으면 TEST_MODE = False 로 전체 실행 → movies_review_naver_v4.csv
   ※ 연도 검증이 처음 적용되므로 기존 결과를 잇지 않고 전체를 새로 수집하는 것을 권장.
      (중단 후 재실행하면 v4 파일 기준으로 이어서 진행됨)
"""

import os
import csv
import json
import re
import time
import urllib.parse

import pandas as pd

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    InvalidSessionIdException,
    NoSuchWindowException,
)


# -------------------------------
# 설정
# -------------------------------

TEST_MODE = False

# 테스트 케이스: (제목, 개봉연도) — 검증 로직의 모든 경로를 커버
TEST_KEYS = [
    ("기생충", 2019),      # V1 정상 (연도 일치)
    ("곤지암", 2018),      # V1 정상 (소규모)
    ("터널", 2016),        # V1 불일치(2025 외국영화) → V2로 해결돼야 함
    ("베테랑", 2015),      # V1 연도표기 없음 → V2로 해결돼야 함
    ("로마의 휴일", 2017),  # V1 불일치(1955) → V2로 해결돼야 함
    ("마녀", 2018),        # 중복 제목 쌍 A (V1에서 잡히는 쪽)
    ("마녀", 2014),        # 중복 제목 쌍 B (V1/V2 불일치 → V3 감독 검색 시도)
    ("보호자", 2023),      # 중복 제목 쌍 A
    ("보호자", 2014),      # 중복 제목 쌍 B
]

INPUT_XLSX = "KMDb_and_KOBIS_통합본.xlsx"
OUTPUT_CSV = (
    "movies_review_naver_v4_1_TEST.csv" if TEST_MODE else "movies_review_naver_v4.csv"
)
FIELDNAMES = ["제목", "개봉연도", "URL", "리뷰", "상태"]

HEADLESS = True
MAX_REVIEWS = 100

# [조건부 대기] 스크롤(바닥 점프) 후 목록 변화를 이 간격(초)으로 확인하고,
# 변화가 감지되면 즉시 다음 점프. 최대 POLL_TIMEOUT(초)까지만 기다림.
POLL_INTERVAL = 0.2
POLL_TIMEOUT = 1.0   # 수집이 목표보다 적게 나오면 1.5로 올릴 것
# 바닥까지 스크롤해도 새 관람평이 이만큼 연속으로 안 늘어나면 "더 없음" 판단.
NO_CHANGE_LIMIT = 5  # 수집이 목표보다 적게 나오면 8로 올릴 것
# 정보 패널 렌더링 대기(초)
PANEL_WAIT = 6

# [속도] DOM 준비 시점에 바로 진행 (이미지/광고 로딩을 기다리지 않음)
PAGE_LOAD_EAGER = True
# [속도] 이미지 로딩 차단 (텍스트 수집에 불필요. 문제가 생기면 False로)
BLOCK_IMAGES = True


# -------------------------------
# 셀렉터 (사이트 개편 시 여기만 수정)
# -------------------------------

SEL_REVIEW_BOX = "div.lego_review_list._scroller"
SEL_REVIEW_TEXT = "span.desc._text"
SEL_PANEL = "div.cs_common_module"


# -------------------------------
# 진단용 JS: 정보 패널의 제목/연도/고유번호(os) 추출
# -------------------------------

JS_PANEL_INFO = """
var wrap = document.querySelector('div.cs_common_module._au_movie_content_wrap')
        || document.querySelector('div._au_movie_content_wrap')
        || document.querySelector('div.cs_common_module');
if (!wrap) return JSON.stringify({panel: false});

var t = wrap.querySelector('.title_area ._text');
var subs = Array.prototype.map.call(
    wrap.querySelectorAll('.sub_title .txt'),
    function(e){ return e.textContent.trim(); }
);
var year = null;
subs.forEach(function(s){ if (/^(18|19|20)\\d{2}$/.test(s)) year = parseInt(s, 10); });

var hasReview = false;
Array.prototype.forEach.call(wrap.querySelectorAll('a'), function(a){
    if (a.textContent.indexOf('관람평') >= 0) hasReview = true;
});

// 이 영화의 고유번호(os) 추출: 탭 영역의 링크를 우선, 없으면 패널 내 os= 링크
var os = null;
function pickOs(sel){
    var as = wrap.querySelectorAll(sel);
    for (var i = 0; i < as.length; i++){
        var m = (as[i].getAttribute('href') || '').match(/[?&]os=(\\d+)/);
        if (m) return m[1];
    }
    return null;
}
os = pickOs('.sub_tap_area a[href*="os="]') || pickOs('a[href*="os="]');

return JSON.stringify({
    panel: true,
    title: t ? t.textContent.trim() : null,
    year: year,
    has_review_tab: hasReview,
    os: os
});
"""


# -------------------------------
# 관람평 수집 JS (v3과 동일: 보이는 목록 즉석 조회 + 일괄 수집 + 바닥 점프)
# -------------------------------

JS_HARVEST_AND_SCROLL = """
    var box = null;
    var els = document.querySelectorAll(arguments[0]);
    for (var i = 0; i < els.length; i++) {
        if (els[i].offsetParent !== null) { box = els[i]; break; }
    }
    if (!box) return null;

    var texts = Array.prototype.map.call(
        box.querySelectorAll(arguments[1]),
        function (e) { return e.textContent.trim(); }
    ).filter(function (t) { return t.length > 0; });

    var state = [box.querySelectorAll(arguments[1]).length, box.scrollHeight];

    box.scrollTop = box.scrollHeight;   // 바닥 점프 -> 다음 10개 로딩 트리거

    return {texts: texts, state: state};
"""

# 보이는 목록의 현재 상태(아이템 수, 스크롤 높이)만 가볍게 조회 (조건부 대기용)
JS_BOX_STATE = """
    var els = document.querySelectorAll(arguments[0]);
    for (var i = 0; i < els.length; i++) {
        if (els[i].offsetParent !== null) {
            return [els[i].querySelectorAll(arguments[1]).length,
                    els[i].scrollHeight];
        }
    }
    return null;
"""


def wait_for_box_change(driver, prev_state):
    """스크롤 직후 상태(prev_state)와 달라질 때까지 조건부 대기.
    변화 감지 시 즉시 True, POLL_TIMEOUT까지 변화 없으면 False."""
    deadline = time.time() + POLL_TIMEOUT
    while time.time() < deadline:
        time.sleep(POLL_INTERVAL)
        try:
            st = driver.execute_script(JS_BOX_STATE, SEL_REVIEW_BOX, SEL_REVIEW_TEXT)
        except Exception:
            st = None
        if st is not None and prev_state is not None and st != prev_state:
            return True
    return False


def crawl_reviews(driver, max_reviews=100):
    """관람평 페이지(현재 화면)에서 리뷰 수집. 목록이 없으면 빈 리스트."""

    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_REVIEW_BOX))
        )
    except Exception:
        return []

    time.sleep(0.8)  # 진입 직후 DOM 노드 교체(재렌더링) 안정화

    review_list = []
    review_seen = set()
    no_change = 0

    while len(review_list) < max_reviews:

        ret = driver.execute_script(
            JS_HARVEST_AND_SCROLL, SEL_REVIEW_BOX, SEL_REVIEW_TEXT
        )

        if ret is None:
            no_change += 1
            prev_state = None
        else:
            before = len(review_list)
            for t in ret["texts"]:
                if t not in review_seen:
                    review_seen.add(t)
                    review_list.append(t)
                    if len(review_list) >= max_reviews:
                        break
            no_change = 0 if len(review_list) > before else no_change + 1
            prev_state = ret["state"]

        if no_change >= NO_CHANGE_LIMIT:
            break

        # 고정 sleep 대신: 다음 배치가 로딩돼 목록이 변하면 즉시 다음 점프
        wait_for_box_change(driver, prev_state)

    return review_list[:max_reviews]


# -------------------------------
# 검색 → 패널 정보 추출
# -------------------------------

def get_panel_info(driver, query):
    """검색어로 이동해 정보 패널의 {title, year, os, has_review_tab} 반환"""

    url = (
        "https://search.naver.com/search.naver"
        f"?where=nexearch&sm=top_hty&fbm=0&ie=utf8&query={query}"
    )
    driver.get(url)

    try:
        WebDriverWait(driver, PANEL_WAIT).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_PANEL))
        )
    except Exception:
        pass  # 패널 없음도 결과

    time.sleep(0.5)  # 렌더링 안정화

    try:
        return json.loads(driver.execute_script(JS_PANEL_INFO))
    except Exception:
        return {"panel": False}


def click_review_tab(driver):
    """현재 패널의 관람평 탭 클릭 (재렌더링 대비 2회 재시도)"""
    for _ in range(2):
        try:
            tab = WebDriverWait(driver, 8).until(
                EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "관람평"))
            )
            tab.click()
            time.sleep(0.6)
            return True
        except Exception:
            time.sleep(0.8)
    return False


def open_review_by_os(driver, title, os_id):
    """영화 고유번호(os)로 관람평 페이지 URL을 만들어 직접 이동"""
    q = urllib.parse.quote(f"영화 {title} 관람평")
    url = (
        "https://search.naver.com/search.naver"
        f"?where=nexearch&sm=tab_etc&mra=bkEw&pkid=68&os={os_id}&qvt=0&query={q}"
    )
    driver.get(url)
    time.sleep(0.8)


def resolve_and_open(driver, title, ok_years, director):
    """
    검색어를 단계적으로 바꿔가며 '연도가 검증된' 관람평 페이지를 연다.

    Returns
    -------
    (status, detail)
        status: "ok" (관람평 페이지 진입 완료) / "연도불일치" / "패널없음" / "진입실패"
        detail: 경로·연도 기록 문자열
    """

    tried = []  # 각 단계 결과 기록

    # ---------- 1차: "영화 {제목}" ----------
    info = get_panel_info(driver, f"영화 {title}")
    tried.append(f"V1:{info.get('year') if info.get('panel') else '패널없음'}")

    if info.get("panel") and info.get("year") in ok_years:
        if click_review_tab(driver):
            return "ok", "V1"
        tried[-1] += "(관람평탭 클릭실패)"

    # ---------- 2차: "한국영화 {제목}" ----------
    info = get_panel_info(driver, f"한국영화 {title}")
    tried.append(f"V2:{info.get('year') if info.get('panel') else '패널없음'}")

    if info.get("panel") and info.get("year") in ok_years:
        if info.get("has_review_tab") and click_review_tab(driver):
            return "ok", "V2탭"
        if info.get("os"):
            open_review_by_os(driver, title, info["os"])
            # 직접 이동한 페이지의 패널 연도 재확인 (연도 표기가 있으면 반드시 일치해야 함)
            check = json.loads(driver.execute_script(JS_PANEL_INFO))
            if check.get("year") is None or check.get("year") in ok_years:
                return "ok", "V2직접"
            tried[-1] += f"(직접이동 후 연도불일치:{check.get('year')})"

    # ---------- 3차: "영화 {제목} {감독}" ----------
    if director:
        info = get_panel_info(driver, f"영화 {title} {director}")
        tried.append(f"V3감독:{info.get('year') if info.get('panel') else '패널없음'}")

        if info.get("panel") and info.get("year") in ok_years:
            if info.get("has_review_tab") and click_review_tab(driver):
                return "ok", "V3탭"
            if info.get("os"):
                open_review_by_os(driver, title, info["os"])
                check = json.loads(driver.execute_script(JS_PANEL_INFO))
                if check.get("year") is None or check.get("year") in ok_years:
                    return "ok", "V3직접"

    return "연도불일치", ",".join(tried)


# -------------------------------
# 엑셀 로드: (제목, 개봉연도, 제작연도, 감독) 목록
# -------------------------------

df = pd.read_excel(INPUT_XLSX)

targets = []
for _, row in df.iterrows():
    title = str(row["영화명"]).strip()
    if not title or title == "nan":
        continue

    m = re.match(r"((?:18|19|20)\d{2})", str(row["개봉일"]).strip())
    open_year = int(m.group(1)) if m else None

    try:
        prod_year = int(row["제작연도"])
    except Exception:
        prod_year = None

    director = ""
    if pd.notna(row.get("감독")):
        director = str(row["감독"]).split("|")[0].strip()

    targets.append({
        "title": title,
        "open_year": open_year,
        "prod_year": prod_year,
        "director": director,
    })

if TEST_MODE:
    want = {(t, y) for t, y in TEST_KEYS}
    targets = [t for t in targets if (t["title"], t["open_year"]) in want]
    if os.path.exists(OUTPUT_CSV):
        os.remove(OUTPUT_CSV)  # 테스트는 항상 처음부터
    print(f"[테스트 모드] {len(targets)}편 → {OUTPUT_CSV}")


# -------------------------------
# 이어하기: (제목, 개봉연도) 기준
# -------------------------------

done_keys = set()

if os.path.exists(OUTPUT_CSV):
    _prev = pd.read_csv(OUTPUT_CSV, encoding="utf-8-sig")
    for _, r in _prev.iterrows():
        done_keys.add((str(r["제목"]), str(r["개봉연도"])))
    print(f"기존 결과 {len(done_keys)}건 발견 → 건너뛰고 이어서 진행")


# -------------------------------
# 결과 파일: append 모드, 영화 1편마다 즉시 저장
# -------------------------------

new_file = not os.path.exists(OUTPUT_CSV)
out = open(OUTPUT_CSV, "a", encoding="utf-8-sig", newline="")
writer = csv.DictWriter(out, fieldnames=FIELDNAMES)
if new_file:
    writer.writeheader()


def write_rows(title, open_year, url, reviews, status):
    """영화 1편의 결과를 기록 (리뷰 없으면 빈 행 1개로 완료 표시)"""
    if reviews:
        for r in reviews:
            writer.writerow({
                "제목": title, "개봉연도": open_year,
                "URL": url, "리뷰": r, "상태": status,
            })
    else:
        writer.writerow({
            "제목": title, "개봉연도": open_year,
            "URL": url, "리뷰": "", "상태": status,
        })
    out.flush()


# -------------------------------
# 드라이버 생성
# -------------------------------

options = webdriver.ChromeOptions()

if PAGE_LOAD_EAGER:
    options.page_load_strategy = "eager"

if BLOCK_IMAGES:
    options.add_experimental_option(
        "prefs", {"profile.managed_default_content_settings.images": 2}
    )

if HEADLESS:
    options.add_argument("--headless=new")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-gpu")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/126.0.0.0 Safari/537.36"
    )

driver = webdriver.Chrome(options=options)

try:

    for t in targets:

        title = t["title"]
        open_year = t["open_year"]
        key = (title, str(open_year))

        if key in done_keys:
            print(f"[{title}({open_year})] 이미 수집됨 → 건너뜀")
            continue

        print(f"\n[{title}({open_year})] 검색 시작")

        # 검증 통과로 인정할 연도: 개봉연도 또는 제작연도
        # (네이버 패널 연도가 둘 중 무엇을 쓰는지 영화마다 달라서 둘 다 허용)
        ok_years = {y for y in (open_year, t["prod_year"]) if y}

        try:

            if not ok_years:
                # 연도 정보가 없으면 검증 불가 → 기존 방식(1차 검색)으로만 진행하고 표시
                info = get_panel_info(driver, f"영화 {title}")
                if info.get("panel") and click_review_tab(driver):
                    reviews = crawl_reviews(driver, MAX_REVIEWS)
                    st = "ok-연도미상(미검증)" if reviews else "ok-연도미상-리뷰0건"
                    print(f"리뷰 {len(reviews)}개 수집 (연도 미검증)")
                    write_rows(title, open_year, driver.current_url, reviews, st)
                else:
                    write_rows(title, open_year, driver.current_url, [], "패널없음")
                done_keys.add(key)
                continue

            status, detail = resolve_and_open(driver, title, ok_years, t["director"])

            if status != "ok":
                print(f"검증 실패 → 수집 안 함 ({detail})")
                write_rows(title, open_year, driver.current_url, [],
                           f"연도불일치({detail})")
                done_keys.add(key)
                continue

            print(f"관람평 페이지 진입 성공 (경로: {detail})")
            print(driver.current_url)

            reviews = crawl_reviews(driver, MAX_REVIEWS)
            print(f"리뷰 {len(reviews)}개 수집")

            st = f"ok({detail})" if reviews else f"ok({detail})-리뷰0건"
            write_rows(title, open_year, driver.current_url, reviews, st)
            done_keys.add(key)

        except (InvalidSessionIdException, NoSuchWindowException):
            print("브라우저 세션이 종료됨 → 중단합니다. 재실행 시 이어서 진행됩니다.")
            raise

        except Exception as e:
            print(f"{title}({open_year}) : 처리 실패 ({type(e).__name__}: {e})")
            write_rows(title, open_year, driver.current_url, [],
                       f"오류({type(e).__name__})")
            done_keys.add(key)

except KeyboardInterrupt:
    print("\n사용자 중단 — 지금까지의 결과는 저장돼 있습니다. 재실행 시 이어서 진행됩니다.")

finally:

    out.close()

    try:
        driver.quit()
    except Exception:
        pass

    print("저장 완료:", OUTPUT_CSV)

    # 요약 출력
    try:
        _r = pd.read_csv(OUTPUT_CSV, encoding="utf-8-sig")
        summary = _r.groupby(["제목", "개봉연도", "상태"]).size().rename("리뷰수")
        print("\n===== 수집 요약 =====")
        print(summary.to_string())
    except Exception:
        pass
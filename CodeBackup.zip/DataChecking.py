import pandas as pd

IMPORT_FILE = 'KMDb_and_KOBIS_통합본.xlsx'
df = pd.read_excel(IMPORT_FILE)

def count():
        comment_count = (
                df.groupby('movie_title')
                .size()
                .reset_index(name='댓글수')
                .sort_values(by='댓글수', ascending=False))

        comment_count.to_csv('ytb_crawl_count.csv',index=False,encoding='utf-8-sig')

def filtering():
        result = []

        for _,row in df.iterrows():
                genre = row['장르']
                if isinstance(genre, str) and genre.endswith('에로'):
                        result.append(row['영화명'])
        return result

print(filtering())
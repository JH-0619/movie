"""
02 · 원본 PDF에서 '빈 플레이스홀더 박스' 좌표 추출

원본 슬라이드의 빈 자리는 연한 초록(#F3F7F4) 사각형으로 그려져 있다.
그 색으로 채워진 큰 사각형을 모두 찾고, 박스 안에 이미 들어있는
캡션 텍스트("연도별 개봉 편수 / 막대그래프")의 위치도 함께 기록한다.
→ 이후 캡션을 가리지 않는 영역에만 차트를 얹기 위해 필요.
"""
import json
import pdfplumber
from config import SRC_PDF, DATA, PLACEHOLDER_FILL

MIN_W, MIN_H = 120, 100      # 이보다 작은 사각형은 아이콘/장식이므로 제외

rows = []
with pdfplumber.open(SRC_PDF) as pdf:
    for pno, page in enumerate(pdf.pages, 1):
        boxes = [r for r in page.rects
                 if r.get('non_stroking_color') == PLACEHOLDER_FILL
                 and (r['x1'] - r['x0']) > MIN_W
                 and (r['y1'] - r['y0']) > MIN_H]
        for r in sorted(boxes, key=lambda r: (round(r['top']), r['x0'])):
            x0, x1, top, bot = r['x0'], r['x1'], r['top'], r['bottom']
            words = page.crop((x0, top, x1, bot)).extract_words()
            if words:
                lx0 = min(w['x0'] for w in words); lx1 = max(w['x1'] for w in words)
                lt = min(w['top'] for w in words); lb = max(w['bottom'] for w in words)
            else:
                lx0 = lx1 = lt = lb = None
            rows.append(dict(page=pno, bx0=x0, bx1=x1, btop=top, bbot=bot,
                             lx0=lx0, lx1=lx1, ltop=lt, lbot=lb,
                             txt=" ".join(w['text'] for w in words)[:40]))

with open(f"{DATA}/boxes.json", "w", encoding="utf-8") as fp:
    json.dump(rows, fp, ensure_ascii=False, indent=1)

print(f"빈 박스 {len(rows)}개 추출")
for r in rows:
    print(f"  p{r['page']:2d}  {r['bx1']-r['bx0']:6.0f}x{r['bbot']-r['btop']:5.0f}  {r['txt']}")

# -*- coding: utf-8 -*-
"""
기존 수집 결과를 v4 형식으로 이관하는 1회용 스크립트 (seed_v4_from_old.py)

목적
----
전체 실행(review_naver_v4_1.py, TEST_MODE=False) 전에 한 번 실행하면,
이미 수집이 끝난 영화들을 movies_review_naver_v4.csv 에 미리 넣어두어
전체 실행에서 자동으로 건너뛰게 한다. (v4.1의 이어하기는 (제목, 개봉연도) 기준)

이관 대상
--------
1. movies_review_naver_v4_1_TEST.csv : v4 테스트에서 연도 검증까지 끝난 9편 → 그대로 이관
2. movies_review_naver.csv (구버전) : 리뷰 100개를 채운 영화 → 이관하되
   상태를 'ok(구버전이관-연도미검증)' 으로 표시
   (연도 검증 없이 수집된 것이므로, 나중에 의심되면 해당 제목의 행을
    movies_review_naver_v4.csv 에서 지우고 재실행하면 그 영화만 다시 수집됨)

안전장치
-------
- 같은 제목이 엑셀에 2편 있는 중복 제목(마녀, 보호자 등 8쌍)은 구버전 결과가
  어느 쪽 영화인지 확정할 수 없으므로 이관하지 않고 다시 수집하게 둔다.
- movies_review_naver_v4.csv 에 이미 있는 (제목, 개봉연도)는 건드리지 않는다.

실행: python seed_v4_from_old.py  →  이후 review_naver_v4_1.py (TEST_MODE=False) 실행
"""

import os
import re
import pandas as pd

INPUT_XLSX = "KMDb_and_KOBIS_통합본.xlsx"
OLD_CSV = "movies_review_naver.csv"                # 구버전(v2) 결과
TEST_CSV = "movies_review_naver_v4_1_TEST.csv"     # 검증 완료된 테스트 결과
OUT_CSV = "movies_review_naver_v4.csv"             # 전체 실행이 사용할 파일
FIELDNAMES = ["제목", "개봉연도", "URL", "리뷰", "상태"]
MIN_COMPLETE = 100  # 이 개수를 채운 영화만 "완료"로 보고 이관


def main():
    # ---------- 엑셀: 제목 → 개봉연도 매핑 (중복 제목 파악) ----------
    df = pd.read_excel(INPUT_XLSX)
    title_years = {}
    for _, row in df.iterrows():
        t = str(row["영화명"]).strip()
        m = re.match(r"((?:18|19|20)\d{2})", str(row["개봉일"]).strip())
        if not t or t == "nan" or not m:
            continue
        title_years.setdefault(t, []).append(int(m.group(1)))

    dup_titles = {t for t, ys in title_years.items() if len(ys) > 1}

    # ---------- 기존 v4 파일에 이미 있는 키 ----------
    existing_keys = set()
    parts = []
    if os.path.exists(OUT_CSV):
        prev = pd.read_csv(OUT_CSV, encoding="utf-8-sig")
        parts.append(prev)
        existing_keys = {(str(r["제목"]), int(r["개봉연도"]))
                         for _, r in prev.iterrows() if pd.notna(r["개봉연도"])}
        print(f"{OUT_CSV} 기존 {len(existing_keys)}편 유지")

    # ---------- 1) 검증 완료된 테스트 결과 이관 ----------
    n_test = 0
    if os.path.exists(TEST_CSV):
        test = pd.read_csv(TEST_CSV, encoding="utf-8-sig")
        keep = []
        for (t, y), g in test.groupby(["제목", "개봉연도"]):
            if (str(t), int(y)) in existing_keys:
                continue
            keep.append(g)
            existing_keys.add((str(t), int(y)))
            n_test += 1
        if keep:
            parts.append(pd.concat(keep))
        print(f"테스트(검증완료) 이관: {n_test}편")
    else:
        print(f"{TEST_CSV} 없음 → 테스트 결과 이관 생략")

    # ---------- 2) 구버전 결과 중 100개 완료 영화 이관 ----------
    n_old, skipped_dup = 0, []
    if os.path.exists(OLD_CSV):
        old = pd.read_csv(OLD_CSV, encoding="utf-8-sig")
        counts = old.groupby("제목").size()
        complete = [t for t, c in counts.items() if c >= MIN_COMPLETE]

        rows = []
        for t in complete:
            t = str(t)
            if t in dup_titles:
                skipped_dup.append(t)   # 어느 영화인지 확정 불가 → 재수집
                continue
            ys = title_years.get(t)
            if not ys:
                continue                # 엑셀에 없는 제목 → 이관 안 함
            key = (t, ys[0])
            if key in existing_keys:
                continue
            g = old[old["제목"] == t]
            for _, r in g.iterrows():
                rows.append({
                    "제목": t,
                    "개봉연도": ys[0],
                    "URL": r.get("URL", ""),
                    "리뷰": r.get("리뷰", ""),
                    "상태": "ok(구버전이관-연도미검증)",
                })
            existing_keys.add(key)
            n_old += 1

        if rows:
            parts.append(pd.DataFrame(rows))
        print(f"구버전(100개 완료) 이관: {n_old}편"
              + (f" / 중복 제목이라 제외: {skipped_dup}" if skipped_dup else ""))
    else:
        print(f"{OLD_CSV} 없음 → 구버전 이관 생략")

    # ---------- 저장 ----------
    if not parts:
        print("이관할 데이터가 없습니다.")
        return

    merged = pd.concat(parts, ignore_index=True)[FIELDNAMES]
    merged.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")

    n_movies = merged.groupby(["제목", "개봉연도"]).ngroups
    print(f"\n저장 완료: {OUT_CSV} (총 {n_movies}편, {len(merged)}행)")
    print("→ 이제 review_naver_v4_1.py 를 TEST_MODE=False 로 실행하면"
          " 위 영화들은 건너뛰고 나머지만 수집합니다.")


if __name__ == "__main__":
    main()
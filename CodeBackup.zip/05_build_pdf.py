"""
05 · 원본 PDF 위에 차트를 얹어 최종 PDF 생성

원본 파일 자체를 그대로 쓰고(레이아웃·폰트·문구 무수정),
빈 박스 안쪽에만 이미지를 얹는다.
  · 이미지는 박스의 '캡션 위 여백'에 종횡비를 유지한 채 중앙 배치
  · 숫자 빈칸(◯◯◯편, [n]편 등)은 흰 사각형으로 가린 뒤 텍스트 PNG를 덮어씀
"""
import io
import json

import pdfplumber
from PIL import Image
from pypdf import PdfReader, PdfWriter
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

from config import SRC_PDF, DATA, FIT, OUT_PDF, PAGE_W, PAGE_H

boxes = json.load(open(f"{DATA}/boxes.json", encoding="utf-8"))


# ── 박스 찾기 / 배치 영역 계산 ────────────────────────────
def box(page, key, idx=0):
    """page 위에서 캡션에 key가 들어간 빈 박스를 찾는다."""
    cand = [b for b in boxes if b['page'] == page and key in (b['txt'] or "")]
    if not cand:
        cand = [b for b in boxes if b['page'] == page]
    return cand[idx]


def region(b, pad=14, gap=12):
    """박스 안에서 '캡션 위' 영역 → 캡션을 가리지 않는다."""
    top = b['btop'] + pad
    bot = (b['ltop'] - gap) if b['ltop'] else (b['bbot'] - pad)
    return b['bx0'] + pad, top, b['bx1'] - pad, bot


def right_of_label(b, pad=14, gap=18):
    """캡션이 좌측에 있고 세로 여백이 부족할 때 → 캡션 오른쪽 영역 사용."""
    x0 = (b['lx1'] + gap) if b['lx1'] else b['bx0'] + pad
    return x0, b['btop'] + pad, b['bx1'] - pad, b['bbot'] - pad


# ── 배치 계획 ─────────────────────────────────────────────
PLAN = []


def add(page, img, reg):
    PLAN.append((page, f"{FIT}/{img}.png", reg))


add(7,  "p7_collect",       region(box(7, "데이터 수집"), pad=18))
add(7,  "p7_analyze",       region(box(7, "데이터 분석"), pad=18))
add(7,  "p7_clean",         region(box(7, "데이터 정리"), pad=18))
add(9,  "p9_yearly_count",  region(box(9, "연도별 개봉 편수")))
add(9,  "p9_dtype_missing", right_of_label(box(9, "변수 자료형")))
add(10, "p10_rev_raw",      region(box(10, "평균")))
add(10, "p10_rev_log",      region(box(10, "로그 변환")))
add(14, "p14_exclusion",    region(box(14, "제외 사유")))
add(19, "p19_market",       region(box(19, "연도별 시장 규모"), pad=12, gap=8))
add(19, "p19_month",        region(box(19, "개봉 월"), pad=12, gap=8))
add(19, "p19_genre_box",    region(box(19, "장르별 매출액"), pad=12, gap=8))
add(19, "p19_genre_share",  region(box(19, "연도별 장르 비중"), pad=12, gap=8))
add(20, "p20_covid",        region(box(20, "코로나")))
add(21, "p21_kw_top",       region(box(21, "상위")))
add(21, "p21_kw_bot",       region(box(21, "하위")))
add(22, "bp22_budget_rev",  region(box(22, "제작비와 매출액"), pad=12, gap=8))
add(22, "p22_distributor",  region(box(22, "배급사별"), pad=12, gap=8))
add(22, "p22_people",       right_of_label(box(22, "감독"), gap=26))
add(23, "bp23_group3",      region(box(23, "집단별")))
add(24, "bp24_bep_budget",  region(box(24, "제작비 구간별")))
add(24, "bp24_bep_genre",   region(box(24, "장르별 BEP")))
add(25, "bp25_budget_dist", region(box(25, "제작비 분포")))
add(25, "bp25_perf_compare", region(box(25, "관객수 · 매출액")))
add(25, "bp25_genre_compare", region(box(25, "장르 구성")))
add(26, "p26_rating",       region(box(26, "별점")))
add(26, "p26_retention",    region(box(26, "주차별")))
add(26, "p26_perscreen",    region(box(26, "회차당")))
add(27, "p27_riskmap",      region(box(27, "2축")))

# p29는 캡션이 없는 빈 카드 3장 → 좌→우 순서로 배치
p29 = sorted([b for b in boxes if b['page'] == 29], key=lambda b: b['bx0'])
add(29, "p29_genre",       region(p29[0], pad=18))
add(29, "bp29_budget_rev", region(p29[1], pad=18))
add(29, "bp29_bep_budget", region(p29[2], pad=18))

# ── 텍스트 빈칸 치환 (원본 텍스트를 검색해 좌표를 얻음) ────
NUMS = [(9, "◯◯◯편", "688편"), (9, "◯◯개", "51개"), (14, "◯◯◯◯편", "537편")]
LINES = [
    (14, "기본 분석 대상: 약 500편 중 n", "기본 분석 대상: 688편 중 537편"),
    (14, "시놉시스 분석: n", "시놉시스 분석: 537편"),
    (14, "제작비 분석: n", "제작비 분석: 163편"),
    (14, "BEP 분석: n", "BEP 분석: 163편"),
    (14, "관객평가 분석: n", "관객평가 분석: 521편"),
]

# p11은 슬라이드가 래스터 이미지로 삽입돼 텍스트 검색이 불가 →
# 렌더 후 초록 글자 위치를 픽셀로 찾아 확정한 절대 좌표
RASTER = [
    (11, "b11_n1",   333, 596,  470,  638, (1, 1, 1)),
    (11, "b11_n2",   333, 722,  470,  764, (1, 1, 1)),
    (11, "b11_pct1", 528, 610,  700,  636, (1, 1, 1)),
    (11, "b11_pct2", 528, 736,  700,  762, (1, 1, 1)),
    (11, "b11_cmp",  988, 803, 1720,  836, (239 / 255, 244 / 255, 240 / 255)),
]

src = pdfplumber.open(SRC_PDF)


def find_words(page_no, text):
    """페이지에서 연속된 단어열을 찾아 bbox 반환 (토큰 끝 개행 제거)."""
    words = src.pages[page_no - 1].extract_words()
    toks = text.split()
    n = len(toks)
    for i in range(len(words) - n + 1):
        if [w['text'].strip() for w in words[i:i + n]] == toks:
            g = words[i:i + n]
            return (min(w['x0'] for w in g), min(w['top'] for w in g),
                    max(w['x1'] for w in g), max(w['bottom'] for w in g))
    return None


overlays = {}
for page, img, (x0, top, x1, bot) in PLAN:
    overlays.setdefault(page, []).append(("img", img, x0, top, x1, bot))

for page, img, x0, top, x1, bot, bgc in RASTER:
    overlays.setdefault(page, []).append(("raster", f"{FIT}/{img}.png", x0, top, x1, bot, bgc))

for page, snippet, newtext in LINES:
    bb = find_words(page, snippet)
    if bb:
        overlays.setdefault(page, []).append(("txt", newtext, *bb))
    else:
        print("  !! 문구 못 찾음:", page, snippet)

for page, snippet, newtext in NUMS:
    bb = find_words(page, snippet)
    if bb:
        overlays.setdefault(page, []).append(("num", newtext, *bb))
    else:
        print("  !! 숫자 못 찾음:", page, snippet)

src.close()

# ── 합성 ──────────────────────────────────────────────────
_txt_cache = {}


def text_image(txt, color, bold, key):
    """치환 문자열을 PNG로 (차트와 동일한 한글 폰트 사용)."""
    import matplotlib.pyplot as plt
    path = f"{FIT}/_t_{key}.png"
    if key not in _txt_cache:
        fig = plt.figure(figsize=(0.1, 0.1))
        fig.patch.set_alpha(0)
        fig.text(0, 0, txt, fontsize=40, color=color,
                 weight='bold' if bold else 'normal')
        fig.savefig(path, dpi=110, bbox_inches='tight', pad_inches=0.02,
                    transparent=True)
        plt.close(fig)
        _txt_cache[key] = True
    return path


reader = PdfReader(SRC_PDF)
writer = PdfWriter()

for i, pg in enumerate(reader.pages, 1):
    if i in overlays:
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=(PAGE_W, PAGE_H))
        for item in overlays[i]:
            kind = item[0]

            if kind == "raster":
                _, img, x0, top, x1, bot, bgc = item
                c.setFillColorRGB(*bgc)
                c.rect(x0 - 2, PAGE_H - bot - 2, (x1 - x0) + 4, (bot - top) + 4,
                       fill=1, stroke=0)
                im = Image.open(img)
                h = bot - top
                w = h * im.width / im.height
                c.drawImage(ImageReader(img), x0, PAGE_H - bot, w, h, mask='auto')

            elif kind == "img":
                _, img, x0, top, x1, bot = item
                w, h = x1 - x0, bot - top
                im = Image.open(img)
                ar = im.width / im.height
                dw, dh = (w, w / ar) if w / ar <= h else (h * ar, h)   # contain
                cx, cy = x0 + (w - dw) / 2, top + (h - dh) / 2         # 중앙 정렬
                c.drawImage(ImageReader(img), cx, PAGE_H - cy - dh, dw, dh,
                            preserveAspectRatio=True, mask='auto')

            else:   # txt / num
                _, txt, x0, top, x1, bot = item
                c.setFillColorRGB(1, 1, 1)      # 원래 글자를 가림(배경이 흰색)
                c.rect(x0 - 4, PAGE_H - bot - 4, (x1 - x0) + 8, (bot - top) + 8,
                       fill=1, stroke=0)
                is_num = (kind == "num")
                path = text_image(txt, "#1f6440" if is_num else "#1c1c1a",
                                  is_num, f"{i}_{abs(hash(txt)) % 99999}")
                im = Image.open(path)
                lh = bot - top
                dh = lh * (1.02 if is_num else 0.94)
                dw = dh * im.width / im.height
                c.drawImage(ImageReader(path), x0, PAGE_H - bot - (dh - lh) * 0.35,
                            dw, dh, mask='auto')
        c.save()
        buf.seek(0)
        pg.merge_page(PdfReader(buf).pages[0])
    writer.add_page(pg)

with open(OUT_PDF, "wb") as fp:
    writer.write(fp)

print(f"완료: {OUT_PDF}  ({len(writer.pages)}쪽, 이미지 {len(PLAN) + len(RASTER)}개 배치)")

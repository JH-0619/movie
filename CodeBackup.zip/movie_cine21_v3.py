# -*- coding: utf-8 -*-
"""
씨네21(cine21.com) 통합 크롤러 v2
- 영화 검색 -> 상세페이지 -> [전문가 별점/댓글] + [관객(네티즌) 별점/댓글] 수집
- 입력: KMDb_and_KOBIS_통합본.xlsx (1번째 열 = 영화명, 2번째 행부터 데이터)
- 출력: movie_review_cine21.xlsx  (댓글당 1행)
  컬럼: 영화명, 구분(전문가/관객), 작성자, 별점, 코멘트, 작성일

v4 변경사항:
  * '상태' 컬럼 제거. 검색결과없음/댓글없음/오류 사유는 로그 파일에만 기록.
    - 댓글이 없거나 실패한 영화도 영화명만 있는 행 1개를 남김
      (이어하기(RESUME)가 해당 영화를 완료로 인식해 재시도하지 않도록)
    - 실패 영화만 다시 수집하려면 결과 파일에서 그 영화 행을 지우고 재실행

v3 변경사항:
  * '전체 전문가 별점 / 전체 관객 별점 / 전체 리뷰수' 컬럼 제거 (수집 안 함)
    - 단, 관객 리뷰 페이지 수 계산에 필요한 '리뷰(N)' 값은 내부적으로만 사용
  * 영화별 소요 시간 + 전체 소요 시간 측정/출력 추가

v2 변경사항 (debug HTML로 실제 DOM 구조 확인 후 수정):
  * 전문가 평: li 안의 p.name(작성자) / p.num(별점) / div.review(코멘트)를
    정확한 셀렉터로 분리 추출 (v1은 범용 추정 로직이라 작성자/코멘트가 섞였음)
  * 관객 리뷰: 실제 섹션은 #netizen_review_area (ajax 로딩).
    v1의 라벨 폴백이 영화 정보 박스(개봉/등급/시간)를 잘못 잡던 문제 수정.
  * 관객 리뷰는 '더보기'가 아니라 페이지네이션 방식(페이지당 10개).
    사이트 자체 함수 $('#netizen_review_area').nzreview('list', N) 를 직접 호출해
    MAX_AUDIENCE_COMMENTS 개수까지 페이지를 넘기며 수집.

설계 원칙 (web_crawler_development_guide.md 기반):
  * 실패 시 debug_cine21/ 폴더에 스크린샷 + HTML 자동 저장
  * 단계(step)와 URL을 로그에 남겨 실패 지점을 즉시 특정
  * 영화 1건 실패가 전체를 멈추지 않음 / 매 영화 중간 저장 + 이어하기
  * 셀렉터는 SEL_* 상수로 상단에 집약 (사이트 개편 시 여기만 수정)
  * 텍스트 추출은 JS 일괄 반환으로 왕복 통신 최소화

사전 준비:
    pip install selenium pandas openpyxl
    Chrome 설치 (Selenium 4.6+ 는 chromedriver 자동 관리)
"""

import os
import re
import math
import time
import random
import logging
import traceback
import urllib.parse
from datetime import datetime

import pandas as pd

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# ============================ CONFIG ============================
INPUT_FILE = "KMDb_and_KOBIS_통합본.xlsx"  # 같은 폴더에 두기
NAME_COL_INDEX = 0        # 영화명이 있는 열 (0 = 1번째 열)
HEADER_ROWS = 1           # 건너뛸 헤더 행 수 (데이터는 2번째 행부터)

TEST_COUNT = None            # 앞 N개만 테스트. 전체 실행하려면 None
HEADLESS = True           # 창을 보고 싶으면 False
WAIT_SECONDS = 12         # 요소 대기 최대(초)
DELAY_MIN = 2.0           # 영화 사이 최소 대기(초) - 차단 방지
DELAY_MAX = 4.0           # 영화 사이 최대 대기(초)
PAGE_DELAY = 0.8          # 관객 리뷰 페이지 넘김 사이 대기(초)

MAX_AUDIENCE_COMMENTS = 100   # 관객(네티즌) 댓글 최대 수집 개수
MAX_EXPERT_COMMENTS = None    # 전문가 댓글 최대 개수 (None = 전부, 보통 10개 내외)

OUTPUT_FILE = "movie_review_cine21.xlsx"  # 이어하기를 위해 고정 파일명 사용
RESUME = True             # True면 기존 결과 파일에 있는 영화는 건너뜀
DEBUG_DIR = "debug_cine21"  # 실패 시 스크린샷/HTML 저장 폴더
DUMP_FIRST_MOVIE = True   # 첫 영화는 성공해도 debug 덤프 (구조 확인용)
LOG_FILE = "cine21_crawler.log"

# ---------------- 셀렉터 (사이트 개편 시 여기만 수정) ----------------
SEARCH_URL = "https://cine21.com/search/movie/?query={query}"
SEL_RESULT_LINK = "a[href*='movie_id']"     # 검색결과 -> 상세페이지 링크
MAX_RESULTS = 30                            # 정확일치 탐색용 상위 결과 수

# 전문가 별점 섹션:  <section class="expert_star"> <ul class="expert_star_list">
#   <li> <p class="name">김성훈</p> ... <p class="num">7</p>
#        <div class="review">코멘트</div> </li>
SEL_EXPERT_SECTION = "section.expert_star"
SEL_EXPERT_ITEMS = "section.expert_star ul.expert_star_list > li"
SEL_EXPERT_NAME = ".reviewer .name"
SEL_EXPERT_STAR = ".star_wrap .num"
SEL_EXPERT_COMMENT = ".review"

# 관객(네티즌) 리뷰 섹션:  <section id="nzreview"> <div id="netizen_review_area">
#   ajax(/movie/nzreview/list)로 페이지당 10개씩 로딩. 페이지네이션은
#   사이트 자체 jQuery 플러그인 $('#netizen_review_area').nzreview('list', N)
#   <li> <div class="id">100*****</div> <div class="date">2026-07-21 ...</div>
#        <p class="num">6</p> <div class="comment">코멘트</div> </li>
SEL_NZ_AREA = "#netizen_review_area"
SEL_NZ_TITLE = "#netizen_review_area .submain_title"   # '리뷰(18)'
SEL_NZ_ITEMS = "#netizen_review_area ul li"
SEL_NZ_ID = ".id"
SEL_NZ_DATE = ".date"
SEL_NZ_STAR = ".star_wrap .num"
SEL_NZ_COMMENT = ".comment"

NOT_FOUND = "검색결과없음"
# ================================================================


# ---------------------------- 로깅 ----------------------------
def setup_logger():
    log = logging.getLogger("cine21")
    if log.handlers:          # 재실행 시 핸들러 중복 등록 방지
        return log
    log.setLevel(logging.DEBUG)

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter("%(message)s"))

    log.addHandler(fh)
    log.addHandler(ch)
    return log


log = setup_logger()


# ---------------------------- 드라이버 ----------------------------
def build_driver(headless: bool = True) -> webdriver.Chrome:
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1280,3000")
    options.add_argument("--lang=ko-KR")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
    return webdriver.Chrome(options=options)


def dump_debug(driver, tag: str):
    """실패 시점 스냅샷: 스크린샷 + 페이지 소스를 DEBUG_DIR에 저장."""
    try:
        os.makedirs(DEBUG_DIR, exist_ok=True)
        safe = re.sub(r"[^0-9A-Za-z가-힣_-]", "_", tag)[:50]
        ts = datetime.now().strftime("%H%M%S")
        base = os.path.join(DEBUG_DIR, f"{safe}_{ts}")
        driver.save_screenshot(base + ".png")
        with open(base + ".html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        log.debug(f"debug 덤프 저장: {base}.png / .html")
    except Exception as e:
        log.debug(f"debug 덤프 실패: {e}")


# ---------------------------- 검색 ----------------------------
def normalize(s: str) -> str:
    """비교용: 한글/영문/숫자만 남기고 공백·특수문자 제거 + 소문자화."""
    return re.sub(r"[^0-9A-Za-z가-힣]", "", (s or "")).lower()


def get_movie_url(driver, movie_name: str):
    """영화 전용 검색에서 제목이 일치하는 상세 URL 반환. 없으면 None.
    1) 완전일치 우선, 2) 없으면 공백/특수문자 무시한 정규화 일치."""
    query = urllib.parse.quote(movie_name)
    driver.get(SEARCH_URL.format(query=query))
    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_RESULT_LINK))
        )
    except TimeoutException:
        return None
    time.sleep(0.8)  # 렌더 직후 안정화 (stale 방지)

    # JS 일괄 추출로 왕복 통신 최소화 + stale 원천 차단
    items = driver.execute_script(
        """
        var links = document.querySelectorAll(arguments[0]);
        var out = [];
        for (var i = 0; i < links.length && i < arguments[1]; i++) {
            var t = (links[i].textContent || '').trim();
            if (t) out.push({title: t, href: links[i].href});
        }
        return out;
        """,
        SEL_RESULT_LINK, MAX_RESULTS,
    )

    target = movie_name.strip()
    target_n = normalize(movie_name)
    exact_hit = None
    norm_hit = None
    for it in items:
        title = it["title"].splitlines()[0].strip()
        if exact_hit is None and title == target:
            exact_hit = it["href"]
        if norm_hit is None and normalize(title) == target_n:
            norm_hit = it["href"]
    if exact_hit is None and norm_hit is not None:
        log.debug(f"'{movie_name}': 완전일치 없음 -> 정규화 일치로 선택")
    return exact_hit or norm_hit


# '리뷰(18)' 제목에서 숫자를 읽는 정규식 (페이지 수 계산용, 결과에는 저장 안 함)
RE_COUNT_PAREN = re.compile(r"\(\s*([\d,]+)\s*\)")


def fmt_elapsed(seconds: float) -> str:
    """소요 시간을 '1시간 2분 3.4초' / '2분 3.4초' / '3.4초' 형태로 변환."""
    seconds = max(0.0, seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h >= 1:
        return f"{int(h)}시간 {int(m)}분 {s:.1f}초"
    if m >= 1:
        return f"{int(m)}분 {s:.1f}초"
    return f"{s:.1f}초"


# ---------------------- JS 일괄 추출 스크립트 ----------------------
JS_EXTRACT_EXPERT = """
var out = [];
var lis = document.querySelectorAll(arguments[0]);
for (var i = 0; i < lis.length; i++) {
    var li = lis[i];
    function g(sel) {
        var el = li.querySelector(sel);
        return el ? (el.textContent || '').trim() : '';
    }
    out.push({
        writer: g(arguments[1]),
        star: g(arguments[2]),
        comment: g(arguments[3])
    });
}
return out;
"""

JS_EXTRACT_AUDIENCE = """
var out = [];
var lis = document.querySelectorAll(arguments[0]);
for (var i = 0; i < lis.length; i++) {
    var li = lis[i];
    function g(sel) {
        var el = li.querySelector(sel);
        return el ? (el.textContent || '').trim() : '';
    }
    var item = {
        writer: g(arguments[1]),
        date: g(arguments[2]),
        star: g(arguments[3]),
        comment: g(arguments[4])
    };
    if (item.comment || item.star) out.push(item);   // 빈 li 제외
}
return out;
"""

# 관객 리뷰 페이지 넘김: 사이트 자체 jQuery 플러그인 호출
JS_NZ_GO_PAGE = """
try {
    if (typeof $ === 'undefined' || typeof $.fn.nzreview === 'undefined') return false;
    var area = $(arguments[0]);
    if (area.length === 0) return false;
    area.nzreview('list', arguments[1]);
    return true;
} catch (e) { return false; }
"""

# 현재 리뷰 목록의 시그니처(내용 변경 감지용): 첫 항목의 id+date+개수
JS_NZ_SIGNATURE = """
var lis = document.querySelectorAll(arguments[0]);
if (lis.length === 0) return '';
var f = lis[0];
function g(sel) {
    var el = f.querySelector(sel);
    return el ? (el.textContent || '').trim() : '';
}
return lis.length + '|' + g(arguments[1]) + '|' + g(arguments[2]);
"""


def get_review_total(driver):
    """'리뷰(18)' 제목에서 전체 리뷰 수를 읽는다. 실패 시 None."""
    txt = driver.execute_script(
        """
        var el = document.querySelector(arguments[0]);
        return el ? (el.textContent || '').trim() : '';
        """,
        SEL_NZ_TITLE,
    )
    m = RE_COUNT_PAREN.search(txt or "")
    return int(m.group(1).replace(",", "")) if m else None


def wait_signature_change(driver, old_sig, timeout=WAIT_SECONDS):
    """관객 리뷰 목록이 갱신될 때까지 폴링. 갱신되면 True."""
    end = time.time() + timeout
    while time.time() < end:
        sig = driver.execute_script(JS_NZ_SIGNATURE, SEL_NZ_ITEMS, SEL_NZ_ID, SEL_NZ_DATE)
        if sig and sig != old_sig:
            return True
        time.sleep(0.3)
    return False


def collect_audience(driver, movie_name: str):
    """관객(네티즌) 리뷰를 페이지네이션을 따라가며 최대 MAX_AUDIENCE_COMMENTS개 수집.
    반환: (items 리스트, 전체 리뷰수 or None)"""
    # ajax 로딩 완료 대기 (리뷰 0건이면 제목만 뜨거나 아무것도 없을 수 있음)
    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_NZ_TITLE))
        )
    except TimeoutException:
        log.debug(f"'{movie_name}': 관객 리뷰 영역({SEL_NZ_TITLE}) 렌더 안 됨")
        return [], None

    total = get_review_total(driver)
    if total == 0:
        return [], 0

    def extract():
        return driver.execute_script(
            JS_EXTRACT_AUDIENCE, SEL_NZ_ITEMS,
            SEL_NZ_ID, SEL_NZ_DATE, SEL_NZ_STAR, SEL_NZ_COMMENT
        ) or []

    all_items = extract()
    if not all_items:
        return [], total

    per_page = len(all_items)                      # 보통 10
    goal = min(total or MAX_AUDIENCE_COMMENTS, MAX_AUDIENCE_COMMENTS)
    max_page = max(1, math.ceil(goal / max(per_page, 1)))

    seen = {(it["writer"], it["date"], it["comment"]) for it in all_items}

    for page in range(2, max_page + 1):
        if len(all_items) >= goal:
            break
        old_sig = driver.execute_script(
            JS_NZ_SIGNATURE, SEL_NZ_ITEMS, SEL_NZ_ID, SEL_NZ_DATE
        )
        ok = driver.execute_script(JS_NZ_GO_PAGE, SEL_NZ_AREA, page)
        if not ok:
            log.debug(f"'{movie_name}': {page}페이지 호출 실패(nzreview 없음) -> 중단")
            break
        if not wait_signature_change(driver, old_sig):
            log.debug(f"'{movie_name}': {page}페이지 갱신 감지 실패 -> 중단")
            break
        added = 0
        for it in extract():
            key = (it["writer"], it["date"], it["comment"])
            if key in seen:
                continue
            seen.add(key)
            all_items.append(it)
            added += 1
        if added == 0:                             # 마지막 페이지 넘어감
            break
        time.sleep(PAGE_DELAY)

    return all_items[:MAX_AUDIENCE_COMMENTS], total


# ---------------------------- 상세페이지 ----------------------------
def crawl_detail(driver, url: str, movie_name: str, dump_tag=None):
    """상세페이지에서 전문가 댓글 + 관객 댓글을 수집."""
    driver.get(url)

    # 1) 전문가 섹션 대기 (렌더 완료 앵커)
    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_EXPERT_SECTION))
        )
    except TimeoutException:
        pass  # 전문가 평이 없는 영화도 있으므로 진행

    # 2) 스크롤로 지연 로딩 발동
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight/2);")
    time.sleep(0.5)
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(0.8)

    if dump_tag:
        dump_debug(driver, dump_tag)

    # 3) 전문가 댓글 (정확한 셀렉터로 일괄 추출)
    expert_items = driver.execute_script(
        JS_EXTRACT_EXPERT, SEL_EXPERT_ITEMS,
        SEL_EXPERT_NAME, SEL_EXPERT_STAR, SEL_EXPERT_COMMENT
    ) or []
    expert_items = [it for it in expert_items if it["comment"] or it["star"]]
    if MAX_EXPERT_COMMENTS:
        expert_items = expert_items[:MAX_EXPERT_COMMENTS]

    # 4) 관객 댓글 (페이지네이션 순회)
    #    review_total('리뷰(N)')은 상태 판정용으로만 반환, 결과에는 저장 안 함
    audience_items, review_total = collect_audience(driver, movie_name)

    return expert_items, audience_items, review_total


# ---------------------------- 입출력 ----------------------------
COLUMNS = ["영화명", "구분", "작성자", "별점", "코멘트", "작성일"]


def make_row(name, kind="", writer="", star="", comment="", date=""):
    return dict(zip(COLUMNS, [name, kind, writer, star, comment, date]))


def load_movie_names(path: str, max_count):
    if path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path, header=None, skiprows=HEADER_ROWS)
    else:
        df = pd.read_csv(path, header=None, skiprows=HEADER_ROWS, encoding="utf-8")
    names = df.iloc[:, NAME_COL_INDEX].dropna().astype(str).str.strip().tolist()
    names = [n for n in names if n and n.lower() != "nan"]
    # 순서 유지하며 중복 제거
    seen = set()
    uniq = []
    for n in names:
        if n not in seen:
            seen.add(n)
            uniq.append(n)
    return uniq[:max_count] if max_count else uniq


def load_done_movies(path: str) -> set:
    """이어하기: 기존 결과 파일에서 이미 처리된 영화명 집합을 반환.
    (오류났던 영화만 재시도하려면 결과 파일에서 해당 영화 행을 지우고 재실행)"""
    if not (RESUME and os.path.exists(path)):
        return set()
    try:
        df = pd.read_excel(path)
        return set(df["영화명"].dropna().astype(str).str.strip())
    except Exception as e:
        log.warning(f"기존 결과 파일 읽기 실패(무시하고 처음부터): {e}")
        return set()


# ---------------------------- 메인 ----------------------------
def main():
    all_names = load_movie_names(INPUT_FILE, TEST_COUNT)
    done = load_done_movies(OUTPUT_FILE)
    movie_names = [n for n in all_names if n not in done]
    if done:
        log.info(f"이어하기: 기존 결과에 있는 {len(all_names) - len(movie_names)}개 건너뜀")
    log.info(f"총 {len(movie_names)}개 영화 처리 시작")

    # 기존 결과 로드 (이어붙이기)
    rows = []
    if RESUME and os.path.exists(OUTPUT_FILE):
        try:
            rows = pd.read_excel(OUTPUT_FILE).fillna("").to_dict("records")
        except Exception:
            rows = []

    driver = build_driver(headless=HEADLESS)

    def save():
        pd.DataFrame(rows, columns=COLUMNS).to_excel(OUTPUT_FILE, index=False)

    ok_count = 0
    total_start = time.time()
    try:
        for idx, name in enumerate(movie_names, start=1):
            log.info(f"\n[{idx}/{len(movie_names)}] {name}")
            movie_start = time.time()
            step = "1) 검색"
            url = None
            try:
                url = get_movie_url(driver, name)

                if not url:
                    log.info(f"  ⚠️  {NOT_FOUND} (영화명만 기록)")
                    rows.append(make_row(name))  # 이어하기용 표식 행
                    dump_debug(driver, f"notfound_{name}")
                    continue

                step = "2) 상세페이지 수집"
                dump_tag = f"first_{name}" if (DUMP_FIRST_MOVIE and idx == 1) else None
                expert_items, audience_items, review_total = crawl_detail(
                    driver, url, name, dump_tag)

                n_e, n_a = len(expert_items), len(audience_items)
                if n_e == 0 and n_a == 0:
                    # 리뷰 영역('리뷰(N)')이 렌더됐으면 진짜 댓글 없음,
                    # 렌더 자체가 안 됐으면 구조 문제일 수 있으므로 로그로 구분
                    status = "댓글없음" if review_total is not None else "값 못 찾음"
                    rows.append(make_row(name))  # 이어하기용 표식 행
                    if status == "값 못 찾음":
                        dump_debug(driver, f"novalue_{name}")
                else:
                    status = "성공"
                    for it in expert_items:
                        rows.append(make_row(
                            name, "전문가", it["writer"], it["star"],
                            it["comment"], ""))
                    for it in audience_items:
                        rows.append(make_row(
                            name, "관객", it["writer"], it["star"],
                            it["comment"], it["date"]))
                    ok_count += 1

                log.info(f"  댓글 수집  전문가:{n_e}개  관객:{n_a}개  ({status})")

            except Exception as e:
                log.error(f"  ❌ 실패 단계: {step} | URL: {url or '-'} "
                          f"| {type(e).__name__}: {e}")
                log.debug(traceback.format_exc())
                dump_debug(driver, f"error_{name}")
                rows.append(make_row(name))  # 이어하기용 표식 행 (사유는 로그에)

            finally:
                save()  # 매 영화마다 중간 저장
                log.info(f"  ⏱️  소요 시간: {fmt_elapsed(time.time() - movie_start)}")
                if idx < len(movie_names):
                    time.sleep(random.uniform(DELAY_MIN, DELAY_MAX))

    finally:
        save()
        driver.quit()

    total_elapsed = time.time() - total_start
    n = max(len(movie_names), 1)
    log.info(f"\n📁 저장 완료 → {OUTPUT_FILE}  (댓글 수집 성공 {ok_count}/{len(movie_names)})")
    log.info(f"⏱️  전체 소요 시간: {fmt_elapsed(total_elapsed)}"
             f"  (영화당 평균 {fmt_elapsed(total_elapsed / n)}, 대기시간 포함)")
    log.info(f"   로그: {LOG_FILE} / 디버그 덤프: {DEBUG_DIR}/")


if __name__ == "__main__":
    main()
"""
CGV 실관람평 크롤러 v3 (속도 최적화판)
- 엑셀(xlsx) 파일(MOVIE_NAME_COLUMN번째 칼럼, 2번째 행부터)의 영화명을 읽어 CGV 통합검색에서 검색
- 검색결과 중 제목이 가장 잘 일치하는 썸네일을 클릭해 상세페이지로 이동
- 상세페이지의 실관람평을 무한스크롤 하며 REVIEW_COUNT_PER_MOVIE 개수만큼 수집
- 원제목 검색결과가 없으면 수집하지 않고 '검색결과없음(-대체검색어 결과 존재)'로만 기록
- 결과를 엑셀로 저장
- SAVE_INTERVAL 편마다 자동저장, 중단 후 재실행하면 결과 파일에 없는 영화부터 이어서 수집
- 진행상황/오류를 crawl_log.txt에 기록, 실패 시 debug/ 폴더에 스크린샷+HTML 저장
- 영화별/전체 소요 시간을 측정해서 출력

[v3 속도 최적화 내용]
 1) 리뷰 텍스트 추출을 '마지막에 한 번만' JS로 일괄 수행 (요소별 왕복 통신 제거) ← 가장 큰 절감
 2) 고정 sleep 축소 (수집 루프 0.8→0.25초, 리뷰 로딩 루프 0.7→0.4초 등)
 3) pageLoadStrategy='eager' + 이미지 로딩 차단 (BLOCK_IMAGES로 켜고 끔)
 4) 수집 스크롤을 '페이지 하단 점프' 방식으로 변경 (반복 횟수 감소)
"""

import os
import re
import time
import logging
import traceback
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    StaleElementReferenceException,
    ElementClickInterceptedException
)
from selenium.webdriver.common.action_chains import ActionChains
import openpyxl

# ===================== CONFIG (여기 값들만 바꾸면 됩니다) =====================
INPUT_CSV_PATH = "KMDb_and_KOBIS_통합본.xlsx"              # 검색할 영화 목록
OUTPUT_EXCEL_PATH = "movies_review_CGV.xlsx"  # 결과 저장 경로
REVIEW_COUNT_PER_MOVIE = 100               # 영화 1편당 수집할 관람평 개수
SEARCH_URL = "https://cgv.co.kr/tme/itgrSrch"
SCROLL_PAUSE_SEC = 0.25                    # [v3] 스크롤 후 추가 대기시간(초). 명시적 대기가 따로 있어 짧아도 됨
MAX_SCROLL_ATTEMPTS = 25                   # 스크롤해도 더 안 늘어날 때 포기하는 시도 횟수
HEADLESS = True                            # True로 하면 브라우저 창 없이 백그라운드 실행
BLOCK_IMAGES = True                        # [v3] True면 이미지 로딩 차단(속도↑). debug 스크린샷이 회색으로 나오는 단점
SAVE_INTERVAL = 50                        # 영화 몇 편마다 자동저장할지 (100 = 100편마다 저장)
MOVIE_NAME_COLUMN = 1                      # 영화명이 있는 칼럼 위치 (1 = 첫 번째 칼럼(A열), 2 = 두 번째 칼럼(B열))
LOG_PATH = "crawl_log.txt"                 # 로그 파일 경로 (실행할 때마다 이어서 기록됨)
DEBUG_DIR = "debug"                        # 실패 시 스크린샷/HTML을 저장할 폴더

# ─── 테스트 모드 ───────────────────────────────────────────────
# 영화 목록의 상위 TEST_COUNT개만 크롤링합니다.
# 전체 크롤링으로 되돌리려면 아래 줄을 TEST_COUNT = None 으로 바꾸거나
# 줄 맨 앞에 #을 붙여 주석처리 하세요. (주석처리해도 전체 크롤링으로 동작)
# TEST_COUNT = 10
# ──────────────────────────────────────────────────────────────

# ─── 셀렉터 모음 (CGV 사이트 개편으로 요소를 못 찾으면 여기만 수정) ───
# 클래스명 끝의 해시(__RburS 등)는 사이트가 재배포될 때마다 바뀔 수 있어서
# 부분일치([class*="..."])로 사용합니다.
SEL_FIRST_THUMB = '[class*="filmographySlide_posterSlide"] button'   # 검색결과 썸네일들
SEL_REVIEW_SECTION = '#reviewSection'                                # 리뷰 섹션 컨테이너 (로드 직후에도 존재)
SEL_REVIEW_EMPTY = '#reviewSection .empty-section'                   # 실관람평 0건일 때 나오는 빈 상태 표시
SEL_REVIEW_LIST = 'ul[class*="reviewList"]'                          # 실관람평 목록
SEL_SORT_BTN = 'button[class*="sortBtn"]'                            # 최신순 정렬 버튼
SEL_REVIEW_TEXT = 'p[class*="reveiwCard_txt"]'                       # 관람평 텍스트
# ──────────────────────────────────────────────────────────────

log = logging.getLogger("cgv")


def setup_logger():
    """콘솔 + crawl_log.txt 파일에 동시에 로그를 남김"""
    if log.handlers:          # 중복 실행 시 핸들러가 겹치지 않도록
        return
    log.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s",
                            "%Y-%m-%d %H:%M:%S")
    fh = logging.FileHandler(LOG_PATH, encoding="utf-8")
    fh.setLevel(logging.DEBUG)      # 파일에는 traceback 포함 전부 기록
    fh.setFormatter(fmt)
    sh = logging.StreamHandler()
    sh.setLevel(logging.INFO)       # 화면에는 주요 내용만 출력
    sh.setFormatter(fmt)
    log.addHandler(fh)
    log.addHandler(sh)


def fmt_elapsed(seconds):
    """초 → '1시간 2분 3초' 형태 문자열"""
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}시간 {m}분 {s}초"
    if m:
        return f"{m}분 {s}초"
    return f"{s}초"


def dump_debug(driver, movie_name):
    """실패 원인 추적용: 현재 화면 스크린샷과 HTML을 debug/ 폴더에 저장"""
    try:
        os.makedirs(DEBUG_DIR, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|]', "_", str(movie_name))[:50]
        ts = datetime.now().strftime("%H%M%S")
        png = os.path.join(DEBUG_DIR, f"{safe}_{ts}.png")
        html = os.path.join(DEBUG_DIR, f"{safe}_{ts}.html")
        driver.save_screenshot(png)
        with open(html, "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        log.info(f"  -> 디버그 파일 저장: {png} / {html} (열어보면 실패 시점 화면을 볼 수 있음)")
    except Exception as e:
        log.warning(f"  -> 디버그 파일 저장 실패: {e}")


def get_movie_list(xlsx_path):
    """xlsx의 MOVIE_NAME_COLUMN번째 칼럼, 2번째 행부터 영화명을 읽어옴"""
    col = MOVIE_NAME_COLUMN - 1
    movies = []
    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    ws = wb.active  # 첫 번째 시트
    for row in ws.iter_rows(min_row=2, values_only=True):  # 첫 행(헤더) 제외
        if len(row) > col and row[col] is not None and str(row[col]).strip():
            movies.append(str(row[col]).strip())
    wb.close()
    return movies


def create_driver():
    options = webdriver.ChromeOptions()
    if HEADLESS:
        options.add_argument("--headless=new")
    # [v3] DOM만 준비되면 바로 다음 단계 진행 (이미지/광고 로딩을 기다리지 않음)
    options.page_load_strategy = "eager"
    if BLOCK_IMAGES:
        # [v3] 이미지 로딩 차단: 리뷰 텍스트 수집에 이미지는 불필요 → 로드/스크롤 속도 향상
        # (단, 검색결과 썸네일의 alt 속성은 HTML에 그대로 있어 제목 일치 판별에는 영향 없음)
        options.add_experimental_option("prefs", {
            "profile.managed_default_content_settings.images": 2,
        })
    options.add_argument("--window-size=1400,1000")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    # 헤드리스일 때 UA에 'HeadlessChrome'이 들어가 봇으로 감지되는 것 방지
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    )
    return webdriver.Chrome(options=options)


# ─── stale 방지 헬퍼: 요소 참조를 파이썬에 들고 있지 않고 ───
# ─── 실행 시점에 브라우저 안에서 querySelector로 찾아 즉시 조작 ───

def js_scroll_into_view(driver, css_selector):
    """실행 시점에 브라우저 안에서 요소를 찾아 스크롤. 요소가 있으면 True."""
    return driver.execute_script("""
        var el = document.querySelector(arguments[0]);
        if (el) { el.scrollIntoView({block:'center', behavior:'instant'}); return true; }
        return false;
    """, css_selector)


def count_elements(driver, css_selector):
    """[v3] 요소 개수만 왕복 1회로 확인 (find_elements + 요소별 접근보다 훨씬 빠름)"""
    return driver.execute_script(
        "return document.querySelectorAll(arguments[0]).length;", css_selector)


def extract_texts(driver, css_selector):
    """[v3] 해당 셀렉터의 모든 요소 텍스트를 왕복 1회로 일괄 추출.
    (기존 방식은 요소 1개당 왕복 1회 × 매 반복이라 수집 시간의 대부분을 차지했음)"""
    return driver.execute_script("""
        var els = document.querySelectorAll(arguments[0]);
        var out = [];
        for (var i = 0; i < els.length; i++) {
            var t = (els[i].innerText || '').trim();
            if (t) out.push(t);
        }
        return out;
    """, css_selector)


def norm_title(s):
    """제목 비교용 정규화: 공백/특수문자 제거 + 소문자화"""
    return re.sub(r'[\s\[\]().,:·\-–—|!?~〈〉<>"\'’]+', '', str(s)).lower()


def pick_best_thumb(driver, movie_name):
    """검색결과 썸네일 중 영화명과 가장 잘 일치하는 것을 선택.
    '[LIVE CLASS 씨네퍼퓸] 범죄도시2' 같은 특별상영 항목이 첫 번째로 오는 경우가 있어
    '무조건 첫 썸네일 클릭'은 위험함. 제목 정보를 못 얻으면 첫 썸네일로 폴백."""
    target = norm_title(movie_name)
    best, best_score = None, -1
    for btn in driver.find_elements(By.CSS_SELECTOR, SEL_FIRST_THUMB):
        try:
            label = btn.get_attribute("innerText") or ""
            for img in btn.find_elements(By.TAG_NAME, "img"):
                label += " " + (img.get_attribute("alt") or "")
            cand = norm_title(label)
            if cand and cand == target:
                score = 100                     # 완전 일치
            elif cand and target and target in cand:
                # 제목을 포함하지만 수식어가 붙음 → 길이 차이만큼 감점
                score = 80 - min(40, len(cand) - len(target))
            else:
                score = 0                       # 제목 정보 없음/불일치
            if score > best_score:
                best, best_score = btn, score
        except StaleElementReferenceException:
            continue
    if best is not None and best_score < 100:
        log.info(f"  -> 썸네일 제목 일치도 점수 {best_score}로 선택 (100=완전일치, 0=판별불가)")
    return best


def activate_review_loading(driver, wait):
    """리뷰 섹션으로 스크롤해 지연 로딩을 발동시킨 뒤 리뷰 목록이 나타날 때까지 대기.
    CGV 신규 사이트는 리뷰 목록이 처음부터 DOM에 있지 않고, 리뷰 섹션(#reviewSection)이
    화면에 보여야 렌더링되므로 반드시 '스크롤 → 대기' 순서여야 함.
    모든 DOM 조작은 실행 시점에 브라우저 안에서 요소를 찾는 방식(stale 방지).
    반환: True = 리뷰 목록 있음, False = 실관람평 0건(empty-section) 페이지"""
    # 1) 리뷰 섹션 껍데기가 생길 때까지 대기 (참조는 사용하지 않고 버림)
    wait.until(
        EC.presence_of_element_located((By.CSS_SELECTOR, SEL_REVIEW_SECTION))
    )

    # 2) JS로 즉석 조회해 섹션으로 스크롤. 재렌더링 타이밍이면 잠깐 기다렸다 재시도
    for _ in range(5):
        if js_scroll_into_view(driver, SEL_REVIEW_SECTION):
            break
        time.sleep(0.4)   # [v3] 0.6 → 0.4

    # 3) 조금씩 추가 스크롤하면서 '리뷰 목록' 또는 '빈 상태 표시'가 생길 때까지 대기 (최대 15초)
    deadline = time.time() + 15
    while time.time() < deadline:
        if (count_elements(driver, SEL_REVIEW_LIST) > 0
                or count_elements(driver, SEL_REVIEW_TEXT) > 0):
            break
        # 실관람평이 0건인 페이지는 empty-section이 렌더링됨 → 기다릴 필요 없이 즉시 판정
        if count_elements(driver, SEL_REVIEW_EMPTY) > 0:
            log.info("  -> 이 페이지에는 등록된 실관람평이 없습니다 (empty-section 감지).")
            return False
        driver.execute_script(
            "window.scrollBy({top:300, left:0, behavior:'instant'});")
        time.sleep(0.4)   # [v3] 0.7 → 0.4
    else:
        raise TimeoutException(
            "리뷰 섹션까지 스크롤했지만 리뷰 목록이 나타나지 않음 "
            "(셀렉터 불일치 가능성 → debug HTML에서 실제 클래스명 확인 필요)")

    time.sleep(0.5)   # [v3] 1.0 → 0.5

    # 4) 최신순 정렬 버튼: JS로 즉석 조회해 클릭. 없으면 무시 (실패 사유가 되지 않도록)
    for _ in range(2):
        clicked = driver.execute_script("""
            var b = document.querySelector(arguments[0]);
            if (b) { b.scrollIntoView({block:'center'}); b.click(); return true; }
            return false;
        """, SEL_SORT_BTN)
        if not clicked:
            log.info("  -> 정렬 버튼을 찾지 못해 기본 정렬 순서로 수집합니다.")
            break
        time.sleep(1.2)

    return True


def search_and_open_first_result(driver, wait, movie_name):
    """검색창에 영화명을 입력하고 Enter, 제목이 일치하는 검색결과 클릭 후
    상세페이지 로딩까지 대기. 실패 시 어느 단계에서 멈췄는지 로그에 기록됨.

    반환: (status, note)
      - ("ok", None)        : 상세페이지 진입 + 리뷰 목록 있음 → 수집 진행
      - ("no_reviews", None): 상세페이지 진입했으나 실관람평 0건
      - ("not_found", 문구) : 원제목 검색결과 없음 → 수집하지 않고 '문구'를 엑셀에 기록
        대체 검색어로는 결과가 있어도 다른 시리즈를 잘못 수집할 위험이 있어
        클릭하지 않고 "검색결과없음-'대체검색어'로 검색 결과 존재"로 기록만 함."""
    step = "1) 검색 페이지 접속"
    try:
        driver.get(SEARCH_URL)

        step = "2) 검색창(input#swrd) 찾기"
        search_box = wait.until(EC.presence_of_element_located((By.ID, "swrd")))
        search_box.clear()
        search_box.send_keys(movie_name)
        search_box.send_keys(Keys.ENTER)

        step = f"3) 검색결과 썸네일 찾기 ({SEL_FIRST_THUMB})"
        try:
            wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, SEL_FIRST_THUMB)))
        except TimeoutException:
            # 원제목으로 검색결과가 없는 경우:
            # 대체 검색어(특수문자 앞부분)로 '존재 여부만' 확인하고 수집은 하지 않음
            simplified = re.split(r"[-–:：]", movie_name)[0].strip()
            if not simplified or simplified == movie_name:
                log.info("  -> 검색결과가 없습니다. (대체 검색어 만들 수 없음)")
                return ("not_found", "검색결과없음")

            step = f"3-1) 대체 검색어('{simplified}') 존재 여부 확인"
            log.info(f"  -> 원제목 검색결과 없음. 대체 검색어 '{simplified}'의 "
                     f"결과 존재 여부만 확인합니다 (수집하지 않음).")
            driver.get(SEARCH_URL)
            search_box = wait.until(
                EC.presence_of_element_located((By.ID, "swrd")))
            search_box.clear()
            search_box.send_keys(simplified)
            search_box.send_keys(Keys.ENTER)
            try:
                wait.until(EC.presence_of_element_located(
                    (By.CSS_SELECTOR, SEL_FIRST_THUMB)))
                # 대체 검색어로는 결과가 있음 → 다른 시리즈 오수집 방지를 위해 기록만
                note = f"검색결과없음-'{simplified}'로 검색 결과 존재"
                log.info(f"  -> {note}")
                return ("not_found", note)
            except TimeoutException:
                log.info("  -> 대체 검색어로도 검색결과가 없습니다.")
                return ("not_found", "검색결과없음")

        step = "3-2) 제목이 일치하는 썸네일 선택/클릭"
        time.sleep(1.0)   # [v3] 1.5 → 1.0 (stale 재시도 루프가 안전망 역할)
        clicked = False
        for _ in range(4):
            try:
                thumb = pick_best_thumb(driver, movie_name)
                if thumb is None:
                    raise TimeoutException("클릭할 썸네일이 없음")
                driver.execute_script("arguments[0].click();", thumb)
                clicked = True
                break
            except (StaleElementReferenceException,
                    ElementClickInterceptedException):
                time.sleep(0.8)   # 재렌더링이 끝난 뒤 새 요소로 다시 시도
        if not clicked:
            raise TimeoutException("썸네일 클릭 반복 실패(stale)")

        step = f"4) 상세페이지 리뷰 섹션 찾기 ({SEL_REVIEW_SECTION})"
        wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, SEL_REVIEW_SECTION)))

        step = "5) 실관람평 로딩(리뷰 섹션 스크롤 후 목록 대기)"
        if activate_review_loading(driver, wait):
            return ("ok", None)
        return ("no_reviews", None)

    except TimeoutException:
        log.error(f"  -> [{movie_name}] 실패 단계: {step}")
        log.error(f"  -> 현재 URL: {driver.current_url}")
        raise


def collect_reviews(driver, target_count):
    """[v3] 무한스크롤 하며 목표 개수만큼 관람평 텍스트 수집.
    - 루프 중에는 '개수만' 확인 (왕복 1회)
    - 텍스트 추출은 루프 종료 후 '한 번만' JS로 일괄 수행
    - 스크롤은 페이지 하단으로 점프해 무한스크롤 트리거 횟수 대비 반복 최소화"""
    stale_attempts = 0
    last_count = 0

    while stale_attempts < MAX_SCROLL_ATTEMPTS:
        current = count_elements(driver, SEL_REVIEW_TEXT)
        if current >= target_count:
            break

        # 스크롤해도 리뷰 개수가 그대로면 더 이상 로딩할 게 없다고 판단
        if current == last_count:
            stale_attempts += 1
        else:
            stale_attempts = 0
        last_count = current

        # [v3] 페이지 하단으로 점프 + 휠 이벤트 (무한스크롤 트리거)
        driver.execute_script(
            "window.scrollTo({top: document.body.scrollHeight, left:0, behavior:'instant'});")
        ActionChains(driver).scroll_by_amount(0, 700).perform()

        # 새 리뷰가 로딩될 때까지 대기 (늘어나면 즉시 다음 반복으로)
        try:
            WebDriverWait(driver, 4).until(
                lambda d: count_elements(d, SEL_REVIEW_TEXT) > current)
        except TimeoutException:
            pass

        time.sleep(SCROLL_PAUSE_SEC)   # [v3] 0.8 → 0.25 (위 명시적 대기가 주 대기 역할)

    texts = extract_texts(driver, SEL_REVIEW_TEXT)   # [v3] 마지막에 한 번만 일괄 추출
    return texts[:target_count]


def load_or_create_workbook(output_path):
    """결과 파일이 이미 있으면 열어서 이어쓰기, 없으면 새로 생성.
    반환: (워크북, 시트, 이미 수집된 영화명 set)"""
    if os.path.exists(output_path):
        wb = openpyxl.load_workbook(output_path)
        ws = wb.active
        done = set()
        for row in ws.iter_rows(min_row=2, values_only=True):  # 헤더 제외
            if row and row[0] is not None and str(row[0]).strip():
                done.add(str(row[0]).strip())
        log.info(f"기존 결과 파일 발견: {output_path}")
        log.info(f"  -> 이미 수집된 영화 {len(done)}개는 건너뛰고 이어서 수집합니다.")
        return wb, ws, done

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "movie_review_cgv"
    ws.append(["영화명", "관람평"])
    return wb, ws, set()


def append_movie_rows(ws, movie_name, reviews, note=None):
    """영화 1편 결과를 시트에 추가.
    note가 있으면(검색결과없음 등) 관람평 대신 note를 기록"""
    if note:
        ws.append([movie_name, note])
    elif reviews:
        for review in reviews:
            ws.append([movie_name, review])
    else:
        ws.append([movie_name, "(수집된 관람평 없음)"])


def main():
    setup_logger()
    total_start = time.time()
    log.info("=" * 60)
    log.info("크롤링 시작 (v3 속도 최적화판)")

    movies = get_movie_list(INPUT_CSV_PATH)
    log.info(f"검색할 영화 {len(movies)}개")
    # 잘못된 칼럼을 읽고 있으면 여기서 바로 티가 남 (영화명이 아닌 숫자/날짜가 보이면 MOVIE_NAME_COLUMN 확인)
    log.info(f"영화 목록 미리보기(앞 5개): {movies[:5]}")

    # 테스트 모드: TEST_COUNT가 정의돼 있고 None이 아니면 상위 N개만
    test_count = globals().get("TEST_COUNT")
    if test_count:
        movies = movies[:test_count]
        log.info(f"[테스트 모드] 상위 {test_count}개만 크롤링합니다: {movies}")

    # 결과 파일이 있으면 이어하기: 이미 수집된 영화는 건너뜀
    wb, ws, done = load_or_create_workbook(OUTPUT_EXCEL_PATH)
    targets = [m for m in movies if m not in done]
    log.info(f"이번에 수집할 영화 {len(targets)}개: {targets}")

    if not targets:
        log.info("모든 영화가 이미 수집되어 있습니다. 종료합니다.")
        return

    driver = create_driver()
    wait = WebDriverWait(driver, 10)

    pending_since_save = 0  # 마지막 저장 이후 처리한 영화 수
    processed = 0           # 이번 실행에서 처리한 영화 수
    success = 0             # 관람평을 1개 이상 수집한 영화 수

    try:
        for i, movie_name in enumerate(targets, 1):
            movie_start = time.time()
            log.info(f"[{i}/{len(targets)}] [{movie_name}] 검색 중...")
            reviews, note = [], None
            try:
                # (status, note) 반환: ok=수집 / no_reviews=관람평 0건 / not_found=검색결과 없음
                status, note = search_and_open_first_result(driver, wait, movie_name)
                if status == "ok":
                    reviews = collect_reviews(driver, REVIEW_COUNT_PER_MOVIE)
                    log.info(f"  -> 관람평 {len(reviews)}개 수집 완료"
                             f" (소요 {fmt_elapsed(time.time() - movie_start)})")
                elif status == "no_reviews":
                    log.info(f"  -> 관람평 0개 (페이지에 실관람평 없음,"
                             f" 소요 {fmt_elapsed(time.time() - movie_start)})")
                else:  # "not_found"
                    log.info(f"  -> 기록: {note}"
                             f" (소요 {fmt_elapsed(time.time() - movie_start)})")
            except TimeoutException:
                log.error("  -> 검색결과 또는 상세페이지를 찾지 못했습니다. 건너뜁니다.")
                log.debug(traceback.format_exc())   # 상세 traceback은 로그 파일에만
                dump_debug(driver, movie_name)
            except Exception as e:
                log.error(f"  -> 예기치 못한 오류: {type(e).__name__}: {e}")
                log.debug(traceback.format_exc())
                dump_debug(driver, movie_name)

            append_movie_rows(ws, movie_name, reviews, note)
            processed += 1
            if reviews:
                success += 1
            pending_since_save += 1

            # 일정 간격(SAVE_INTERVAL편)마다 자동저장
            if pending_since_save >= SAVE_INTERVAL:
                wb.save(OUTPUT_EXCEL_PATH)
                pending_since_save = 0
                log.info(f"  -> 자동저장 완료: {OUTPUT_EXCEL_PATH}")

    except KeyboardInterrupt:
        log.warning("사용자 중단(Ctrl+C). 여기까지 저장하고 종료합니다.")

    finally:
        # 어떤 상황(에러/중단)에서도 마지막 상태를 저장
        wb.save(OUTPUT_EXCEL_PATH)
        driver.quit()
        total = time.time() - total_start
        log.info(f"저장 완료: {OUTPUT_EXCEL_PATH}")
        log.info(f"처리 결과: {processed}편 중 {success}편 수집 성공, "
                 f"{processed - success}편 실패/관람평 없음")
        if processed:
            log.info(f"총 소요 시간: {fmt_elapsed(total)} "
                     f"(편당 평균 {fmt_elapsed(total / processed)})")
        else:
            log.info(f"총 소요 시간: {fmt_elapsed(total)}")


if __name__ == "__main__":
    main()
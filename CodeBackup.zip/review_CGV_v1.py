import os
import time
import random
import re
import unicodedata
import pandas as pd
from difflib import SequenceMatcher

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# ── 설정 ────────────────────────────────────────────────
INPUT_FILE = "KMDb_and_KOBIS_통합본.xlsx"   # 영화 목록 (영화명 + 감독 컬럼 필요)
DIRECTOR_COL = "감독"
TEST_COUNT = None                  # 테스트: 앞 N개. 전체 실행하려면 None
DELAY_MIN = 2.0
DELAY_MAX = 4.0
WAIT_TIMEOUT = 30                    # 페이지 기본 요소(검색창) 대기 최대(초)
SCROLL_TRIES = 25                    # 검색결과 목록 아래로 스크롤 최대 반복
SCROLL_WAIT = 1.5                    # 스크롤 후 '새 항목 로드'를 기다리는 최대(초) — 뜨면 즉시 진행
RESULT_WAIT = 8                      # 결과/평점 요소 대기 최대(초) — 뜨면 즉시 진행, 없으면 이 시간 내 포기
OUTPUT_FILE = "CGV_평점_결과.xlsx"   # 고정 파일명 → 여기에 이어받기
RETRY_FAILED = True                  # True: 지난번 실패한 영화는 다시 시도 / False: 실패도 건너뜀
MATCH_THRESHOLD = 0.6                # 필모그래피 제목 유사도 최소 기준 (0~1)
MAX_PERSON_CANDIDATES = 6            # 동명이인 인물(탭) 최대 확인 수

SEARCH_URL = "https://cgv.co.kr/tme/itgrSrch"
DETAIL_URL = "https://cgv.co.kr/cnm/cgvChart/movieChart/{num}"

DEBUG_SEARCH_DUMPED = False   # 첫 검색결과 페이지 구조 저장용


def extract_rating(driver):
    """<dt>...에그지수</dt><dd>83%</dd> 구조에서 dd의 값을 추출. 실패하면 None."""
    try:
        dd = driver.find_element(
            By.XPATH, "//dt[contains(.,'에그지수')]/following-sibling::dd[1]"
        )
        text = dd.text.strip()
        if text:
            return text
    except NoSuchElementException:
        pass
    return None


def extract_review_count(driver):
    """reviewArea 안의 <h2>실관람평 29,826</h2>에서 숫자만 추출. 실패하면 None."""
    try:
        el = driver.find_element(
            By.XPATH,
            "//div[contains(@class,'reviewArea')]//h2[contains(text(),'실관람평')]"
        )
        m = re.search(r"실관람평\s*([\d,]+)", el.text)
        if m:
            return m.group(1)
    except NoSuchElementException:
        pass
    return None


# ── 영화 목록 읽기 (엑셀: 영화명 + 감독) ─────────────────
df = pd.read_excel(INPUT_FILE)
df = df.dropna(subset=[df.columns[0]])
titles = df.iloc[:, 0].astype(str).str.strip()               # 1번째 열 = 영화명
if DIRECTOR_COL in df.columns:
    directors = df[DIRECTOR_COL].fillna("").astype(str).str.strip()
else:
    print(f"⚠️  '{DIRECTOR_COL}' 컬럼이 없습니다. 감독 검색을 할 수 없습니다.")
    directors = pd.Series([""] * len(df), index=df.index)
movie_list = list(zip(titles, directors))
if TEST_COUNT:
    movie_list = movie_list[:TEST_COUNT]

# ── 브라우저 ────────────────────────────────────────────
# 'unable to connect to renderer' 등 크롬 실행 불안정 방지용 옵션
_opts = Options()
_opts.add_argument("--no-sandbox")
_opts.add_argument("--disable-dev-shm-usage")
_opts.add_argument("--disable-gpu")
_opts.add_argument("--remote-allow-origins=*")
_opts.add_argument("--disable-extensions")
_opts.add_argument("--start-maximized")
driver = webdriver.Chrome(options=_opts)
wait = WebDriverWait(driver, WAIT_TIMEOUT)

results = []


def save_results():
    out = pd.DataFrame(results)
    if not out.empty:
        out = out.rename(columns={"제목": "영화 제목", "url": "링크"})
        out = out[["영화 제목", "감독", "평점", "평가건수", "상태", "링크"]]
    out.to_excel(OUTPUT_FILE, index=False)


def normalize_title(s):
    """비교용: NFC 정규화 후 한글/영문/숫자만 남기고 공백·특수문자 전부 제거."""
    s = unicodedata.normalize("NFC", str(s or ""))   # 분해된 한글(NFD) → 결합형
    return re.sub(r"[^0-9A-Za-z가-힣]", "", s)


def similarity(target, cand):
    """글자 유사도만: 특수문자·공백을 제거한 순수 문자 기준 SequenceMatcher 비율(0~1).
    (접두어/부분일치/속편 같은 특수 보정 없이 글자만 비교)"""
    a, b = normalize_title(target), normalize_title(cand)
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def primary_director(d):
    """'박은경 | 이동하' / '홍길동,김철수' → 대표 감독 1명만."""
    d = str(d or "")
    for sep in ["|", ",", "·", "/"]:
        d = d.split(sep)[0]
    return d.strip()


def search_query(title, keep_space=False):
    """검색용 대표 제목.
    · ':' '：' '(' 는 무조건 앞부분만 사용.
    · 대시(-)·콤마(,)·세로줄(| │ ｜ ∣) 는 앞부분이 2자 이상일 때 잘라서 앞부분만 사용
      ('좋은놈,나쁜놈,이상한놈'→'좋은놈', '임영웅│...'→'임영웅', 'T-34'는 보호).
    · 앞부분이 1자라 못 자르면 콤마만 제거 ('날, 보러와요'→'날 보러와요').
    keep_space=False 면 띄어쓰기까지 전부 제거해 다 붙인다."""
    t = str(title).strip()
    q = re.split(r"[:：(（]", t)[0].strip()          # 콜론/괄호 앞까지 (무조건)
    parts = re.split(r"[-–—,|│｜∣]", q)              # 대시·콤마·세로줄로 자름
    if len(parts) > 1 and len(parts[0].strip()) >= 2:
        q = parts[0].strip()                         # 앞부분 2자 이상 → 자르기
    else:
        q = q.replace(",", " ")                      # 못 자르면(앞이 1자) 콤마만 제거
    q = re.sub(r"\s+", " ", q).strip()
    if not keep_space:
        q = re.sub(r"\s+", "", q)
    if q:
        return q
    fb = re.sub(r"\s+", " ", t.replace(",", " ")).strip()   # 폴백
    return fb if keep_space else re.sub(r"\s+", "", fb)


def _collect_items():
    """현재 검색결과 페이지의 영화 항목에서 (제목, 번호or None) 리스트 수집.
    제목 = strong.bestChartList_name, 번호 = 포스터 img src의 /Poster/.../번호/ (포스터 없으면 None)."""
    out = []
    for li in driver.find_elements(By.CSS_SELECTOR, "li[class*='bestChartList_chartItem']"):
        try:
            name = li.find_element(By.CSS_SELECTOR, "[class*='bestChartList_name']").text.strip()
        except NoSuchElementException:
            name = ""
        if not name:
            continue
        num = None
        try:
            src = li.find_element(
                By.CSS_SELECTOR, "img[class*='bestChartList_poster']").get_attribute("src") or ""
            m = re.search(r"/Poster/\d+/(\d+)/", src)
            if m:
                num = m.group(1)
        except NoSuchElementException:
            pass
        out.append((name, num))
    return out


def _open_search_results(q):
    """검색어 q 입력 → '영화 검색결과' 클릭 → 영화 항목이 뜰 때까지 대기 → 아래로 스크롤.
    항목이 있으면 True, 결과 없음이면 False."""
    driver.get(SEARCH_URL)
    box = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "input#swrd")))
    box.clear()
    box.send_keys(q)
    box.send_keys(Keys.ENTER)

    # '영화 검색결과 N건' 버튼이 뜨는 즉시 클릭
    try:
        btn = WebDriverWait(driver, RESULT_WAIT).until(EC.element_to_be_clickable((
            By.XPATH, "//button[contains(., '영화 검색결과')]"
        )))
        driver.execute_script("arguments[0].click();", btn)
    except TimeoutException:
        pass

    # 영화 항목이 뜨는 즉시 진행 — 없으면 결과 없음
    try:
        WebDriverWait(driver, RESULT_WAIT).until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "li[class*='bestChartList_chartItem']")))
    except TimeoutException:
        return False

    # 목록이 스크롤로 더 로드되면 → 항목이 '더 늘어나는 즉시' 계속, 안 늘면 종료
    for _ in range(SCROLL_TRIES):
        n = len(driver.find_elements(By.CSS_SELECTOR, "li[class*='bestChartList_chartItem']"))
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        try:
            WebDriverWait(driver, SCROLL_WAIT).until(
                lambda d: len(d.find_elements(
                    By.CSS_SELECTOR, "li[class*='bestChartList_chartItem']")) > n)
        except TimeoutException:
            break
    return True


def _search_and_collect(q):
    """검색어 q로 검색결과를 열고 (제목, 번호or None) 리스트 반환."""
    global DEBUG_SEARCH_DUMPED
    if not _open_search_results(q):
        return []
    if not DEBUG_SEARCH_DUMPED:
        with open("debug_search.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        DEBUG_SEARCH_DUMPED = True
        print("   -> debug_search.html 저장됨 (검색결과 구조 확인용)")
    return _collect_items()


def _click_item_get_num(q, target):
    """포스터가 없어 번호를 못 얻은 영화: q로 다시 검색 → 제목 최고 매칭 항목 클릭 →
    이동한 상세 URL(/movieChart/번호)에서 번호를 읽어 반환."""
    if not _open_search_results(q):
        return None
    best_li, best_r = None, -1.0
    for li in driver.find_elements(By.CSS_SELECTOR, "li[class*='bestChartList_chartItem']"):
        try:
            name = li.find_element(By.CSS_SELECTOR, "[class*='bestChartList_name']").text.strip()
        except NoSuchElementException:
            continue
        r = similarity(target, name)
        if r > best_r:
            best_r, best_li = r, li
    if best_li is None:
        return None
    try:
        btn = best_li.find_element(By.CSS_SELECTOR, "button[class*='bestChartList_itemLink']")
        driver.execute_script("arguments[0].click();", btn)
    except NoSuchElementException:
        return None
    # 상세페이지로 이동하며 URL에 번호(/movieChart/숫자)가 들어오길 대기
    try:
        WebDriverWait(driver, WAIT_TIMEOUT).until(
            lambda d: re.search(r"/movieChart/(\d+)", d.current_url))
    except TimeoutException:
        pass
    m = re.search(r"/movieChart/(\d+)", driver.current_url)
    return m.group(1) if m else None


def find_movie_num_by_title(title):
    """제목을 (1) 부제 제거+띄어쓰기 유지, (2) 부제 제거+띄어쓰기 제거 두 가지로 검색해
    결과를 합치고, 원래 전체 제목과 글자 유사도가 가장 높은 영화의 CGV 번호 반환.
    포스터가 없어 번호가 없는 영화는 그 항목을 클릭해 상세 URL에서 번호를 얻는다."""
    q_spaced = search_query(title, keep_space=True)    # 1) 부제 제거 + 띄어쓰기 유지
    q_nospace = search_query(title, keep_space=False)  # 2) 부제 제거 + 띄어쓰기 제거
    queries = []
    for q in (q_spaced, q_nospace):
        if q and q not in queries:
            queries.append(q)

    best = None   # (유사도, 제목, 번호or None, 검색어)
    for q in queries:
        print(f"   (검색어: '{q}')")
        for name, num in _search_and_collect(q):
            r = similarity(title, name)
            if best is None or r > best[0]:
                best = (r, name, num, q)
        if best and best[0] >= 0.95:   # 정확일치면 2차 검색 생략
            break

    if not best or best[0] < MATCH_THRESHOLD:
        if best:
            print(f"   ⚠️ 최고 매칭 '{best[1]}' 유사도 {best[0]:.2f} < {MATCH_THRESHOLD} → 불일치")
        else:
            print("   ⚠️ 검색결과에서 후보를 찾지 못함")
        return None

    r, bt, num, q = best
    if num:
        print(f"   ▶ 매칭: '{bt}' (유사도 {r:.2f}) → num {num}")
        return num
    # 포스터 없는 영화 → 항목을 클릭해서 번호 확인
    print(f"   ▶ 매칭(포스터없음): '{bt}' (유사도 {r:.2f}) → 클릭해 번호 확인")
    num = _click_item_get_num(q, title)
    if num:
        print(f"      → num {num}")
        return num
    print("      ⚠️ 클릭으로도 번호를 못 얻음")
    return None


# ── 이어받기: 기존 결과 로드 ─────────────────────────────
done_map = {}
if os.path.exists(OUTPUT_FILE):
    try:
        prev_df = pd.read_excel(OUTPUT_FILE)
        for _, r in prev_df.iterrows():
            tv = str(r.get("영화 제목", "") or "").strip()
            if not tv:
                continue
            done_map[normalize_title(tv)] = {
                "제목": tv,
                "감독": (None if pd.isna(r.get("감독")) else r.get("감독")),
                "평점": (None if pd.isna(r.get("평점")) else r.get("평점")),
                "평가건수": (None if pd.isna(r.get("평가건수")) else r.get("평가건수")),
                "상태": str(r.get("상태", "") or "").strip(),
                "url": (None if pd.isna(r.get("링크")) else r.get("링크")),
            }
        n_ok = sum(1 for v in done_map.values() if v["상태"] == "성공")
        print(f"🔁 이어받기: 기존 {len(done_map)}건 로드 (성공 {n_ok}) ← {OUTPUT_FILE}")
        if RETRY_FAILED:
            n_fail = len(done_map) - n_ok
            if n_fail:
                print(f"    ↳ 실패 {n_fail}건은 이번에 다시 시도합니다.")
    except Exception as e:
        print(f"⚠️  기존 결과 못 읽음 → 처음부터: {e}")
        done_map = {}
else:
    print("ℹ️  기존 결과 파일 없음 → 처음부터 시작합니다.")


# ── 메인 ────────────────────────────────────────────────
try:
    for idx, (title, director) in enumerate(movie_list, 1):
        title = str(title).strip()

        # 이미 처리된 영화면 건너뛰기 (성공 → 항상 skip / 실패 → RETRY_FAILED 에 따름)
        key = normalize_title(title)
        prev = done_map.get(key)
        if prev is not None and (prev["상태"] == "성공" or not RETRY_FAILED):
            results.append(prev)
            print(f"[{idx}/{len(movie_list)}] {title} ⏭️  이미 {prev['상태']} → 건너뜀")
            save_results()
            continue

        print(f"\n[{idx}/{len(movie_list)}] {title}  (감독: {director or '없음'})")

        rating = None
        review_count = None
        status = "실패"

        try:
            num = find_movie_num_by_title(title)
            if not num:
                print("  ⚠️  CGV 검색결과에서 일치 영화 못 찾음")
                status = "검색 매칭 실패"
            else:
                driver.get(DETAIL_URL.format(num=num))

                # 에그지수(평점)가 뜨는 즉시 추출 — 없으면 RESULT_WAIT 내 진행
                try:
                    WebDriverWait(driver, RESULT_WAIT).until(EC.presence_of_element_located((
                        By.XPATH, "//dt[contains(.,'에그지수')]/following-sibling::dd[1]")))
                except TimeoutException:
                    pass
                rating = extract_rating(driver)

                # 실관람평 탭은 늦게 뜨거나 없을 수 있음 → 타임아웃 나도 평점은 유지
                try:
                    tab = WebDriverWait(driver, RESULT_WAIT).until(EC.element_to_be_clickable((
                        By.XPATH,
                        "//button[contains(@class,'titleTab_tabTitle') and contains(.,'실관람평')]"
                    )))
                    driver.execute_script("arguments[0].click();", tab)
                    # 실관람평 수치가 뜨는 즉시 추출
                    try:
                        WebDriverWait(driver, RESULT_WAIT).until(EC.presence_of_element_located((
                            By.XPATH,
                            "//div[contains(@class,'reviewArea')]//h2[contains(text(),'실관람평')]")))
                    except TimeoutException:
                        pass
                    review_count = extract_review_count(driver)
                except TimeoutException:
                    print("  (실관람평 탭 없음 → 평가건수 생략)")

                if rating:
                    status = "성공"
                    print(f"  ✅ 평점: {rating} / 평가건수: {review_count}")
                else:
                    status = "평점 요소 못 찾음"
                    print("  -> 평점 요소를 찾지 못했습니다.")

        except Exception as e:
            print(f"  ❌ 오류: {type(e).__name__}")
            status = f"오류: {type(e).__name__}"

        results.append({
            "제목": title,
            "감독": director,
            "평점": rating,
            "평가건수": review_count,
            "상태": status,
            "url": driver.current_url,
        })

        save_results()
        if idx < len(movie_list):
            time.sleep(random.uniform(DELAY_MIN, DELAY_MAX))

    print(f"\n📁 저장 완료 → {OUTPUT_FILE}")
    print(f"총 {len(results)}건 중 {sum(r.get('상태')=='성공' for r in results)}건 성공.")

except KeyboardInterrupt:
    print("\n⏹️  중단됨. 여기까지 저장합니다.")

finally:
    save_results()
    driver.quit()
    print(f"저장 파일: {OUTPUT_FILE}")
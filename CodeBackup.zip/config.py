"""공통 설정 — 경로 · 색상 · matplotlib 한글 폰트"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

# ── 입력 파일 ─────────────────────────────────────────────
SRC_PDF     = "/mnt/user-data/uploads/살려야한다__Copy_.pdf"
MAIN_XLSX   = "/mnt/project/KMDb_and_KOBIS_통합본_병합완료_2.xlsx"
BUDGET_XLSX = "/mnt/user-data/uploads/기본데이터_공유시트.xlsx"

# ── 출력 경로 ─────────────────────────────────────────────
DATA = "data"     # 중간 산출물(pkl, json)
FIT  = "fit"      # 박스 크기에 맞춘 차트 PNG
OUT  = "out"      # 최종 PDF
OUT_PDF = f"{OUT}/살려야한다_제작비반영.pdf"
for d in (DATA, FIT, OUT):
    os.makedirs(d, exist_ok=True)

# ── 색상 (원본 PPT 팔레트) ────────────────────────────────
BG    = "#F3F7F4"   # 플레이스홀더 박스 배경색 → 차트 배경을 여기 맞춰 이질감 제거
MAIN  = "#1f6440"
SUB   = "#5e9874"
ACC   = "#c96a2e"
LIGHT = "#a3c8af"
MUTED = "#6b6b66"
GREY  = "#C9CFCB"

PAGE_W, PAGE_H = 1920.0, 1080.0          # 원본 슬라이드 크기(pt)
PLACEHOLDER_FILL = (0.952941, 0.968627, 0.956863)   # 빈 박스 채움색

# ── 한글 폰트 ─────────────────────────────────────────────
_FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
fm.fontManager.addfont(_FONT)
plt.rcParams['font.family'] = 'Noto Sans CJK JP'   # 이 .ttc가 등록되는 패밀리명
plt.rcParams['axes.unicode_minus'] = False


# ── 차트 헬퍼 ─────────────────────────────────────────────
def newfig(w_pt, h_pt):
    """박스 크기(pt)에 정확히 맞는 Figure 1개."""
    fig, ax = plt.subplots(figsize=(w_pt / 72, h_pt / 72))
    fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
    return fig, ax


def newfigs(w_pt, h_pt, n, vertical=False):
    """박스 크기에 맞는 다중 패널 Figure."""
    import numpy as np
    if vertical:
        fig, axes = plt.subplots(n, 1, figsize=(w_pt / 72, h_pt / 72))
    else:
        fig, axes = plt.subplots(1, n, figsize=(w_pt / 72, h_pt / 72))
    fig.patch.set_facecolor(BG)
    for a in np.atleast_1d(axes):
        a.set_facecolor(BG)
    return fig, axes


def clean(ax, size=8):
    """상/우 축 제거 + 눈금 톤다운."""
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(labelsize=size, colors=MUTED)
    for sp in ax.spines.values():
        sp.set_color("#CFD8D2")


def save(fig, name):
    fig.savefig(f"{FIT}/{name}.png", dpi=200, bbox_inches='tight',
                facecolor=BG, edgecolor='none', pad_inches=0.06)
    plt.close(fig)
    print("  ", name)


def text_png(name, s, color, weight='normal', size=40):
    """문자열을 투명 배경 PNG로 렌더(원본 텍스트 위에 덮어쓰기용)."""
    fig = plt.figure(figsize=(.1, .1))
    fig.patch.set_alpha(0)
    fig.text(0, 0, s, fontsize=size, color=color, weight=weight, linespacing=1.35)
    fig.savefig(f"{FIT}/{name}.png", dpi=110, bbox_inches='tight',
                pad_inches=0.02, transparent=True)
    plt.close(fig)
    print("  ", name)

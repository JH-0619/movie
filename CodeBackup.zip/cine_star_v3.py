# -*- coding: utf-8 -*-
"""
씨네21(cine21.com) 관객 별점 평균 크롤러 (통합판)
- cine21_star.py(1차 전체 크롤링) + cine21_star_v2.py(실패 건 재조사)를 하나로 통합
- 영화 검색 -> 상세페이지 -> 관객 별점 평균만 수집
- 입력: KMDb_and_KOBIS_통합본_수정.xlsx
    1번째 열 = 영화명, 8번째 열 = 감독, 2번째 행부터 데이터
- 출력: movie_star_cine21.xlsx  (영화당 1행)
  컬럼: 영화명, 관객 별점

통합 방식:
  기존에는 [1단계: 전 영화 제목일치 크롤링] -> [2단계: 실패 영화만 재검색·감독매칭]
  을 두 파일로 나눠 실행했지만, 이 통합판은 영화 1개를 처리할 때
  아래 3단계를 바로 이어서 시도하므로 한 번 실행으로 끝난다.
  (실패 영화를 나중에 다시 검색하는 중복 요청도 사라짐)

  1차) 원래 영화명으로 검색 -> 제목 완전일치/정규화 일치      (기존 cine21_star.py)
  2차) 1차 실패 시, 띄어쓰기·문장부호를 제거한 영화명으로
       재검색 -> 제목 일치                                    (기존 v2)
  3차) 2차도 실패 시, 검색결과 상위 후보의 상세페이지를 열어
       입력 파일 8번째 열의 '감독' 이름과 대조 -> 일치 시 수집 (기존 v2)
       * 제목이 달라도 감독이 같으면 동일 영화로 판단.
         대체 검색 결과를 무턱대고 수집하지 않기 위한 검증 장치.
         감독 매칭으로 수집된 건은 로그에 '검수 권장'으로 표시됨.

이어하기 / 재조사:
  * RETRY_EMPTY=True(기본): 기존 결과 파일에서 '관객 별점'이 채워진 영화만
    건너뛰고, 비어 있는 영화(검색실패/값없음/오류였던 것)는 다시 조사.
    기존의 빈 행은 버리고 새 결과로 대체하므로 중복 행이 생기지 않음.
    -> 예전 cine21_star.py 결과 파일을 그대로 두고 이 통합판을 실행하면
       실패했던 영화만 2·3차 기준까지 포함해 자동으로 재조사된다.
  * RETRY_EMPTY=False: 결과 파일에 있는 영화는 값이 없어도 전부 건너뜀.

설계 원칙 (web_crawler_development_guide.md 기반):
  * 실패 시 debug_cine21_star/ 폴더에 스크린샷 + HTML 자동 저장
  * 단계(step)와 URL을 로그에 남겨 실패 지점을 즉시 특정
  * 영화 1건 실패가 전체를 멈추지 않음 / 매 영화 중간 저장 + 이어하기
  * 어떤 단계에서 매칭됐는지 로그에 기록 (감독 매칭 건은 사후 검수 대상)
  * 영화별/전체 소요 시간 측정 출력

사전 준비:
    pip install selenium pandas openpyxl
    Chrome 설치 (Selenium 4.6+ 는 chromedriver 자동 관리)
"""

import os
import re
import time
import random
import logging
import traceback
import urllib.parse
from datetime import datetime

import pandas as pd

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# ============================ CONFIG ============================
INPUT_FILE = "KMDb_and_KOBIS_통합본_수정.xlsx"  # 같은 폴더에 두기
NAME_COL_INDEX = 0        # 영화명이 있는 열 (0 = 1번째 열)
DIRECTOR_COL_INDEX = 7    # 감독 이름이 있는 열 (7 = 8번째 열)
HEADER_ROWS = 1           # 건너뛸 헤더 행 수 (데이터는 2번째 행부터)

TEST_COUNT = None         # 앞 N개만 테스트. 전체 실행하려면 None
HEADLESS = True           # 창을 보고 싶으면 False
WAIT_SECONDS = 12         # 요소 대기 최대(초)
DELAY_MIN = 2.0           # 영화 사이 최소 대기(초) - 차단 방지
DELAY_MAX = 4.0           # 영화 사이 최대 대기(초)

# 2차(재검색)·3차(감독 매칭) 폴백 사용 여부.
# False로 두면 예전 cine21_star.py처럼 1차 제목일치만 시도한다.
USE_FALLBACK = True
# 3차(감독 매칭) 단계에서 상세페이지를 열어 확인할 검색결과 후보 수.
# 후보마다 페이지를 1번씩 열기 때문에 크게 잡으면 그만큼 느려짐.
DIRECTOR_CHECK_CANDIDATES = 5

OUTPUT_FILE = "movie_star_cine21.xlsx"  # 이어하기를 위해 고정 파일명 사용
RESUME = True             # True면 기존 결과 파일 기준으로 이어하기
RETRY_EMPTY = True        # True면 기존 결과에서 '관객 별점'이 비어 있는 영화를 다시 조사
                          # (False면 결과 파일에 있는 영화는 값이 없어도 전부 건너뜀)
DEBUG_DIR = "debug_cine21_star"  # 실패 시 스크린샷/HTML 저장 폴더
DUMP_FIRST_MOVIE = True   # 첫 영화는 성공해도 debug 덤프 (구조 확인용)
LOG_FILE = "cine21_star_all.log"

# ---------------- 셀렉터 (사이트 개편 시 여기만 수정) ----------------
SEARCH_URL = "https://cine21.com/search/movie/?query={query}"
SEL_RESULT_LINK = "a[href*='movie_id']"     # 검색결과 -> 상세페이지 링크
MAX_RESULTS = 30                            # 제목일치 탐색용 상위 결과 수

# 별점 박스 (렌더 완료 확인 앵커) / 관객 별점 평균 숫자
SEL_STAR_BOX = "div.movie_detail_star_box_wrap"
SEL_NETIZEN_STAR = "div.movie_detail_star_box_wrap .star_netizen .star_wrap .num"

NOT_FOUND = "검색결과없음"
# ================================================================


# ---------------------------- 로깅 ----------------------------
def setup_logger():
    log = logging.getLogger("cine21_star")
    if log.handlers:          # 재실행 시 핸들러 중복 등록 방지
        return log
    log.setLevel(logging.DEBUG)

    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter("%(message)s"))

    log.addHandler(fh)
    log.addHandler(ch)
    return log


log = setup_logger()


def fmt_elapsed(seconds: float) -> str:
    """소요 시간을 '1시간 2분 3.4초' / '2분 3.4초' / '3.4초' 형태로 변환."""
    seconds = max(0.0, seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h >= 1:
        return f"{int(h)}시간 {int(m)}분 {s:.1f}초"
    if m >= 1:
        return f"{int(m)}분 {s:.1f}초"
    return f"{s:.1f}초"


# ---------------------------- 드라이버 ----------------------------
def build_driver(headless: bool = True) -> webdriver.Chrome:
    options = Options()
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1280,3000")
    options.add_argument("--lang=ko-KR")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
    return webdriver.Chrome(options=options)


def dump_debug(driver, tag: str):
    """실패 시점 스냅샷: 스크린샷 + 페이지 소스를 DEBUG_DIR에 저장."""
    try:
        os.makedirs(DEBUG_DIR, exist_ok=True)
        safe = re.sub(r"[^0-9A-Za-z가-힣_-]", "_", tag)[:50]
        ts = datetime.now().strftime("%H%M%S")
        base = os.path.join(DEBUG_DIR, f"{safe}_{ts}")
        driver.save_screenshot(base + ".png")
        with open(base + ".html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        log.debug(f"debug 덤프 저장: {base}.png / .html")
    except Exception as e:
        log.debug(f"debug 덤프 실패: {e}")


# ---------------------------- 검색 ----------------------------
def normalize(s: str) -> str:
    """비교용: 한글/영문/숫자만 남기고 공백·특수문자 제거 + 소문자화."""
    return re.sub(r"[^0-9A-Za-z가-힣]", "", (s or "")).lower()


def clean_query(name: str) -> str:
    """재검색용: 띄어쓰기·문장부호 제거 (한글/영문/숫자만 남김)."""
    return re.sub(r"[^0-9A-Za-z가-힣]", "", name or "")


def search_candidates(driver, query: str):
    """검색 결과 상위 후보 [{title, href}] 리스트 반환. 없으면 []."""
    driver.get(SEARCH_URL.format(query=urllib.parse.quote(query)))
    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_RESULT_LINK))
        )
    except TimeoutException:
        return []
    time.sleep(0.8)  # 렌더 직후 안정화 (stale 방지)

    # JS 일괄 추출로 왕복 통신 최소화 + stale 원천 차단
    items = driver.execute_script(
        """
        var links = document.querySelectorAll(arguments[0]);
        var out = [];
        var seen = {};
        for (var i = 0; i < links.length && out.length < arguments[1]; i++) {
            var t = (links[i].textContent || '').trim();
            var h = links[i].href;
            if (!t || seen[h]) continue;
            seen[h] = true;
            out.push({title: t.split('\\n')[0].trim(), href: h});
        }
        return out;
        """,
        SEL_RESULT_LINK, MAX_RESULTS,
    ) or []
    return items


def pick_by_title(candidates, movie_name: str):
    """후보 중 제목이 일치하는 상세 URL 반환. 없으면 None.
    1) 완전일치 우선, 2) 없으면 공백/특수문자 무시한 정규화 일치."""
    target = movie_name.strip()
    target_n = normalize(movie_name)
    exact_hit = None
    norm_hit = None
    for it in candidates:
        title = it["title"]
        if exact_hit is None and title == target:
            exact_hit = it["href"]
        if norm_hit is None and normalize(title) == target_n:
            norm_hit = it["href"]
    return exact_hit or norm_hit


# ---------------------------- 상세페이지 ----------------------------
def open_detail(driver, url: str):
    """상세페이지 이동 + 별점 박스 렌더 대기."""
    driver.get(url)
    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, SEL_STAR_BOX))
        )
    except TimeoutException:
        pass  # 없어도 진행 (추출 단계에서 None 처리)
    time.sleep(0.5)  # 렌더 안정화


def extract_netizen_star(driver):
    """현재 상세페이지에서 관객 별점 평균을 추출. 없으면 None."""
    value = driver.execute_script(
        """
        var el = document.querySelector(arguments[0]);
        return el ? (el.textContent || '').trim() : null;
        """,
        SEL_NETIZEN_STAR,
    )
    if value and re.match(r"^\d+(?:\.\d+)?$", value):
        return value
    return None


def extract_directors(driver):
    """현재 상세페이지에서 감독 이름 리스트를 추출.
    구조: <li><p class="title">감독</p><a href="/db/person/...">나홍진</a></li>"""
    names = driver.execute_script(
        """
        var out = [];
        var lis = document.querySelectorAll('li');
        for (var i = 0; i < lis.length; i++) {
            var t = lis[i].querySelector('p.title');
            if (!t || (t.textContent || '').trim() !== '감독') continue;
            var links = lis[i].querySelectorAll('a');
            for (var j = 0; j < links.length; j++) {
                var n = (links[j].textContent || '').trim();
                if (n) out.push(n);
            }
            if (links.length === 0) {
                var raw = (lis[i].textContent || '').replace('감독', '').trim();
                if (raw) out.push(raw);
            }
        }
        return out;
        """
    ) or []
    return names


def split_directors(cell) -> list:
    """입력 파일 감독 칸을 이름 리스트로 분리. (예: '봉준호', '홍길동, 김철수')"""
    if cell is None:
        return []
    text = str(cell).strip()
    if not text or text.lower() == "nan":
        return []
    parts = re.split(r"[,/;·|]", text)
    return [p.strip() for p in parts if p.strip()]


def directors_match(input_directors: list, page_directors: list) -> bool:
    """정규화 후 한 명이라도 일치하면 True. ('나홍진' vs '나홍진 감독' 대응)"""
    ins = [normalize(d) for d in input_directors if normalize(d)]
    pgs = [normalize(d.replace("감독", "")) for d in page_directors if normalize(d)]
    for a in ins:
        for b in pgs:
            if a == b or (len(a) >= 2 and (a in b or b in a)):
                return True
    return False


# ---------------------------- 3단계 매칭 ----------------------------
def find_movie(driver, name: str, input_directors: list):
    """3단계 매칭으로 상세 URL과 매칭 방식을 반환.
    반환: (url or None, 매칭방식 문자열, 감독매칭 시 후보 제목)"""
    # 1차: 원래 영화명 검색 -> 제목 일치  (기존 cine21_star.py와 동일 기준)
    cands1 = search_candidates(driver, name)
    url = pick_by_title(cands1, name)
    if url:
        return url, "1차 제목일치", None

    if not USE_FALLBACK:
        return None, NOT_FOUND, None

    # 2차: 띄어쓰기·문장부호 제거한 영화명으로 재검색 -> 제목 일치
    cleaned = clean_query(name)
    cands2 = []
    if cleaned and cleaned != name.strip():
        log.debug(f"'{name}': 1차 실패 -> 재검색어 '{cleaned}'")
        cands2 = search_candidates(driver, cleaned)
        url = pick_by_title(cands2, name)
        if url:
            return url, "2차 제목일치(재검색)", None

    # 3차: 검색결과 후보의 상세페이지 감독과 입력 파일 감독 대조
    if not input_directors:
        log.debug(f"'{name}': 감독 정보 없음 -> 감독 매칭 생략")
        return None, NOT_FOUND, None

    # 후보 합치기 (2차 우선, 중복 URL 제거)
    merged = []
    seen = set()
    for it in cands2 + cands1:
        if it["href"] in seen:
            continue
        seen.add(it["href"])
        merged.append(it)

    for it in merged[:DIRECTOR_CHECK_CANDIDATES]:
        open_detail(driver, it["href"])
        page_dirs = extract_directors(driver)
        log.debug(f"'{name}': 감독 대조 - 후보 '{it['title']}' 감독:{page_dirs}")
        if directors_match(input_directors, page_dirs):
            return it["href"], f"3차 감독일치(후보 제목:'{it['title']}')", it["title"]

    return None, NOT_FOUND, None


# ---------------------------- 입출력 ----------------------------
COLUMNS = ["영화명", "관객 별점"]


def load_movies(path: str, max_count):
    """(영화명, 감독칸) 리스트 반환. 영화명 기준 순서 유지 중복 제거."""
    if path.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(path, header=None, skiprows=HEADER_ROWS)
    else:
        df = pd.read_csv(path, header=None, skiprows=HEADER_ROWS, encoding="utf-8")

    movies = []
    seen = set()
    for _, row in df.iterrows():
        name = row.iloc[NAME_COL_INDEX]
        name = "" if pd.isna(name) else str(name).strip()
        if not name or name.lower() == "nan" or name in seen:
            continue
        seen.add(name)
        director = row.iloc[DIRECTOR_COL_INDEX] if len(row) > DIRECTOR_COL_INDEX else None
        movies.append((name, split_directors(director)))
    return movies[:max_count] if max_count else movies


def load_previous_results(path: str):
    """이어하기: 기존 결과 파일을 읽어 (완료 영화 집합, 재조사 대상 집합, 기존 행)을 반환.
    - RETRY_EMPTY=True : '관객 별점'이 채워진 영화만 완료로 간주,
                         비어 있는 영화는 재조사 대상 (기존 빈 행은 버리고 새로 수집)
    - RETRY_EMPTY=False: 결과 파일에 있는 영화는 값이 없어도 전부 완료로 간주"""
    if not (RESUME and os.path.exists(path)):
        return set(), set(), []
    try:
        df = pd.read_excel(path).fillna("")
        df["영화명"] = df["영화명"].astype(str).str.strip()
        has_star = df["관객 별점"].astype(str).str.strip() != ""

        if RETRY_EMPTY:
            done = set(df.loc[has_star, "영화명"])
            retry = set(df.loc[~has_star, "영화명"]) - done
            rows = df.loc[has_star].to_dict("records")   # 빈 행은 버림(재수집 후 새로 기록)
        else:
            done = set(df["영화명"])
            retry = set()
            rows = df.to_dict("records")
        return done, retry, rows
    except Exception as e:
        log.warning(f"기존 결과 파일 읽기 실패(무시하고 처음부터): {e}")
        return set(), set(), []


# ---------------------------- 메인 ----------------------------
def main():
    all_movies = load_movies(INPUT_FILE, TEST_COUNT)
    done, retry, rows = load_previous_results(OUTPUT_FILE)
    movies = [(n, d) for n, d in all_movies if n not in done]
    if done or retry:
        n_retry = sum(1 for n, _ in movies if n in retry)
        log.info(f"이어하기: 완료 {len(done)}개 건너뜀"
                 + (f", 관객 별점 비어 있는 {n_retry}개 재조사" if n_retry else ""))
    log.info(f"총 {len(movies)}개 영화 처리 시작")

    driver = build_driver(headless=HEADLESS)

    def save():
        pd.DataFrame(rows, columns=COLUMNS).to_excel(OUTPUT_FILE, index=False)

    ok_count = 0
    match_stats = {"1차": 0, "2차": 0, "3차": 0}
    total_start = time.time()
    try:
        for idx, (name, input_directors) in enumerate(movies, start=1):
            log.info(f"\n[{idx}/{len(movies)}] {name}"
                     + (f" (감독: {', '.join(input_directors)})" if input_directors else ""))
            movie_start = time.time()
            step = "1) 검색/매칭"
            url = None
            try:
                url, matched_via, cand_title = find_movie(driver, name, input_directors)

                if not url:
                    log.info(f"  ⚠️  {NOT_FOUND} - 재검색·감독 매칭까지 실패 (영화명만 기록)")
                    rows.append({"영화명": name, "관객 별점": ""})
                    dump_debug(driver, f"notfound_{name}")
                    continue

                step = "2) 관객 별점 추출"
                # 3차 감독매칭은 이미 상세페이지에 있으므로 재이동 생략
                if not matched_via.startswith("3차"):
                    open_detail(driver, url)
                if DUMP_FIRST_MOVIE and idx == 1:
                    dump_debug(driver, f"first_{name}")
                star = extract_netizen_star(driver)

                if star is None:
                    log.info(f"  ⚠️  관객 별점 값 못 찾음 (매칭:{matched_via}, 영화명만 기록)")
                    rows.append({"영화명": name, "관객 별점": ""})
                    dump_debug(driver, f"novalue_{name}")
                else:
                    rows.append({"영화명": name, "관객 별점": star})
                    ok_count += 1
                    match_stats[matched_via[:2]] = match_stats.get(matched_via[:2], 0) + 1
                    log.info(f"  관객 별점: {star}  (매칭: {matched_via})")
                    if matched_via.startswith("3차"):
                        # 감독 매칭 건은 제목이 다를 수 있으므로 사후 검수 대상으로 표시
                        log.warning(f"  🔎 검수 권장: '{name}' -> 사이트 제목 '{cand_title}'")

            except Exception as e:
                log.error(f"  ❌ 실패 단계: {step} | URL: {url or '-'} "
                          f"| {type(e).__name__}: {e}")
                log.debug(traceback.format_exc())
                dump_debug(driver, f"error_{name}")
                rows.append({"영화명": name, "관객 별점": ""})

            finally:
                save()  # 매 영화마다 중간 저장
                log.info(f"  ⏱️  소요 시간: {fmt_elapsed(time.time() - movie_start)}")
                if idx < len(movies):
                    time.sleep(random.uniform(DELAY_MIN, DELAY_MAX))

    finally:
        save()
        driver.quit()

    total_elapsed = time.time() - total_start
    n = max(len(movies), 1)
    log.info(f"\n📁 저장 완료 → {OUTPUT_FILE}  (별점 수집 성공 {ok_count}/{len(movies)})")
    log.info(f"   매칭 내역: 1차 제목일치 {match_stats.get('1차', 0)}개"
             f" / 2차 재검색 {match_stats.get('2차', 0)}개"
             f" / 3차 감독매칭 {match_stats.get('3차', 0)}개 (검수 권장은 로그 참조)")
    log.info(f"⏱️  전체 소요 시간: {fmt_elapsed(total_elapsed)}"
             f"  (영화당 평균 {fmt_elapsed(total_elapsed / n)}, 대기시간 포함)")
    log.info(f"   로그: {LOG_FILE} / 디버그 덤프: {DEBUG_DIR}/")


if __name__ == "__main__":
    main()
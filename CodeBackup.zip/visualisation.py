import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.font_manager as fm
import os

# 1. 환경 설정 (상수 및 폰트)
MAIN_XLSX = "./KMDb_and_KOBIS_통합본_raw.xlsx"
font_path = '/content/malgun.ttf'
MAIN = "#2E5A88"
MUTED = "#666666"
BG_COLOR = "#F3F7F4"

# 폰트 등록
if os.path.exists(font_path):
    fm.fontManager.addfont(font_path)
    prop = fm.FontProperties(fname=font_path)
    plt.rcParams['font.family'] = prop.get_name()
    plt.rcParams['axes.unicode_minus'] = False
    korean_font = prop
else:
    korean_font = None

# 2. 데이터 로드 및 전처리
df_raw = pd.read_excel(MAIN_XLSX, sheet_name="KMDb_KOBIS")

def to_num(s):
    if pd.isna(s): return np.nan
    if isinstance(s, (int, float)): return float(s)
    return float(str(s).replace(',', ''))

# 매출액 수치화 및 연도 추출
df_raw['전국매출액'] = df_raw['전국매출액'].apply(to_num)
df_raw['개봉일_dt'] = pd.to_datetime(df_raw['개봉일'].astype(str), format='%Y%m%d', errors='coerce')
df_raw['개봉연도'] = df_raw['개봉일_dt'].dt.year

# 필터링 (2015-2024, 극영화, 극장용)
df_target = df_raw[
    (df_raw['개봉연도'] >= 2015) & (df_raw['개봉연도'] <= 2024) &
    (df_raw['영화유형'] == '극영화') & (df_raw['용도'] == '극장용')
].copy()

# 주장르 추출 및 빈도 필터링 (n > 8)
df_target['주장르'] = df_target['장르'].apply(lambda x: str(x).split(',')[0].strip())
genre_counts = df_target['주장르'].value_counts()
over_8_genres = genre_counts[genre_counts > 8].index
df_final = df_target[df_target['주장르'].isin(over_8_genres)].copy()

# 중앙값 기준 정렬 순서
genre_order = df_final.groupby('주장르')['전국매출액'].median().sort_values(ascending=False).index

# 3. 시각화 실행
fig, ax = plt.subplots(figsize=(446/72, 360/72), facecolor=BG_COLOR)
ax.set_facecolor(BG_COLOR)

sns.boxplot(
    data=df_final, x='주장르', y='전국매출액', order=genre_order, hue='주장르',
    ax=ax, legend=False, showfliers=False, linewidth=0.8,
    boxprops=dict(facecolor="#64BC7D", edgecolor="#33AE5D", alpha=0.55),
    medianprops=dict(color="#E5773E", linewidth=1.5),
    whiskerprops=dict(color="#9AA8A8", linewidth=1),
    capprops=dict(color="#9AA8A8", linewidth=1)
)

# 스타일링
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.tick_params(axis='both', which='major', labelsize=7, colors=MUTED)

if korean_font:
    ax.set_title("주요 장르별 성과 수준과 편차 (n > 8)", fontproperties=korean_font, fontsize=8, color=MAIN, pad=10)
    ax.set_xlabel("주장르", fontproperties=korean_font, fontsize=7.5, color=MUTED)
    ax.set_ylabel("전국매출액 (원)", fontproperties=korean_font, fontsize=7.5, color=MUTED)
    plt.setp(ax.get_xticklabels(), fontproperties=korean_font, fontsize=6.8, rotation=45, ha='right')
    plt.setp(ax.get_yticklabels(), fontproperties=korean_font, fontsize=6.8)

plt.tight_layout()
plt.show()
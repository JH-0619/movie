#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 YouTube 미매칭 영화 예고편 댓글 크롤러 (비공식 채널 허용판)
================================================================================

목적
  v2 크롤러가 남긴 unmatched_movies.csv의 영화들에 대해, 채널 제한 없이
  search.list로 예고편(메인/티저/30초/15초 등)을 찾아 '조회수 최다' 영상의
  댓글을 수집한다. 수집한 영상의 URL·채널명을 기록하고, 공식 배급사 채널이
  아닌 영상에는 '공식 유통/배급사 영상이 아님'을 표기한다.

전제
  - v2 크롤러(youtube_trailer_crawler_v2.py)와 같은 폴더에서 실행.
  - 같은 폴더에 필요: unmatched_movies.csv, KMDb_and_KOBIS_통합본.xlsx,
    quota_state.json(v2와 공유 — 키 순서가 같아야 함)
  - API_KEYS 순서는 v2와 동일하게 유지할 것.

쿼터 주의 (v2와 완전히 다름!)
  - search.list는 1회 100유닛. 대상 404편 → 약 41,000유닛 (키 4~5개 분량).
  - 조회수(videos.list) 1유닛 + 댓글 1유닛/편 추가.
  - 키 소진 시 자동 로테이션, 체크포인트로 이어하기 지원.

출력
  - youtube_unofficial_comments.csv : 댓글 + 영상URL/채널명/공식여부 표기
  - unmatched_after_search.csv      : 검색으로도 못 찾은 영화
  - unofficial_checkpoint.json      : 이어하기용 (v2 체크포인트와 별개)

기본값: TEST_LIMIT=3 (약 306유닛으로 동작 검증 후 None으로 전체 실행)
================================================================================
"""

import os
import re
import csv
import sys
import time
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta

try:
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
except ImportError:
    sys.exit("google-api-python-client 가 필요합니다.\n"
             "  pip install google-api-python-client")

try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:
    BASE_DIR = os.getcwd()


# ==============================================================================
#  CONFIG
# ==============================================================================
@dataclass
class Config:
    API_KEYS: list = field(default_factory=lambda: [
        k.strip() for k in os.environ.get("YOUTUBE_API_KEYS", "AIzaSyC9k87emjkdMFhGiEy7u1EkHD1Sabp04L0,"
                                          "AIzaSyBtcXkY906gvcjS2yFCuxV6VCTCePwI-Fs,"
                                          "AIzaSyBi1FBofoxGpoB9bh7OGEcOAe9q5xwsUZs,"
                                          "AIzaSyCWIBN-UE1I2gcQ88bCfa4zNz-TNSsf1tc,"
                                          "AIzaSyC6cRtdw9f3LG-ugOvCD7ogrbpqC9z5KUM,"
                                          "AIzaSyCW9svopNd1IaontqnKUQ8XKl-ncTqLG4c,"
                                          "AIzaSyAlQhEQjX6AEOcHzHU6F2PpQMKoBoTyhPg,"
                                          "AIzaSyB6Uzgcxq4tAaVHC3O7gP27BPK43XT22Lo,"
                                          "AIzaSyAAPHV9KemrsYvGReYQLOtxX843iWoXI_s,"
                                          "AIzaSyA_IJUA0-CcQLQS1aX3SlFkEFygO8H1xVs").split(",") if k.strip()
    ] or [
        # "AIza...키1",  ← v2와 '반드시 같은 순서'로 입력 (쿼터 기록 공유)
    ])

    TEST_LIMIT: int = None            # ★ 3편(~306유닛)으로 검증 후 None으로 전체 실행
    START_INDEX: int = 0

    # ---------------- 검색/매칭 ----------------
    SEARCH_MAX_RESULTS: int = 25   # 결과 수와 무관하게 검색 비용은 100유닛 고정
    RELEASE_DATE_WINDOW_MONTHS: int = 18
    CANDIDATE_POOL: int = 10
    MAX_CANDIDATE_TRIES: int = 3
    # 사유가 이 접두어로 시작하는 행은 처리하지 않음(키즈/실황 — 댓글 차단 또는 연구 제외)
    SKIP_REASON_PREFIXES: tuple = ("제외 키워드",)

    # ---------------- 댓글 ----------------
    COMMENTS_PER_VIDEO: int = 100
    COMMENT_ORDER: str = "relevance"
    COMMENT_TEXT_FORMAT: str = "plainText"

    # ---------------- 재시도 ----------------
    MAX_RETRIES: int = 4
    RETRY_BACKOFF_SEC: float = 2.0
    SLEEP_BETWEEN_MOVIES: float = 0.3

    # ---------------- 쿼터 ----------------
    DAILY_QUOTA_PER_KEY: int = 10000

    # ---------------- 파일 경로 ----------------
    INPUT_UNMATCHED: str = os.path.join(BASE_DIR, "unmatched_movies.csv")
    MOVIES_XLSX: str = os.path.join(BASE_DIR, "KMDb_and_KOBIS_통합본.xlsx")
    OUTPUT_CSV: str = os.path.join(BASE_DIR, "youtube_unofficial_comments.csv")
    STILL_UNMATCHED_CSV: str = os.path.join(BASE_DIR, "unmatched_after_search.csv")
    CHECKPOINT_FILE: str = os.path.join(BASE_DIR, "unofficial_checkpoint.json")
    QUOTA_STATE_FILE: str = os.path.join(BASE_DIR, "quota_state.json")   # v2와 공유
    LOG_FILE: str = os.path.join(BASE_DIR, "unofficial_crawler_run.log")

    COL_TITLE: str = "영화명"
    COL_DISTRIBUTOR: str = "배급사"
    COL_RELEASE: str = "개봉일"


CFG = Config()

# v2에서 검증한 공식 배급사 채널 ID — 검색 결과가 이 채널이면 '공식'으로 표기
OFFICIAL_CHANNEL_IDS = {
    "UCRV0Gb4i99Aj9UiqCE8xlvw": "CJ ENM Movie",
    "UCvvsOdnAQH4fl50DY17eV1A": "쇼박스 SHOWBOX",
    "UCsLHf-l27Rb4CK-i8cmqEEw": "플러스엠 엔터테인먼트",
    "UCC2F35lZ0drUeMJOATXde2g": "롯데엔터테인먼트",
    "UC2-VHbcGqGxNRUv0YIekMkA": "It'sNEW 잇츠뉴",
    "UC8rSvDTd9VI0JYUN9N4_yGQ": "ABOentertainment",
    "UC8AD5KHdsFzp8qoJvS4YSYg": "Warner Bros. Korea",
    "UCSgFhhUGNv8U3qxDDFSDVNA": "ACEMAKER",
    "UC-nDaC5bdCS86jccCWZG7fg": "Little Big Pictures",
    "UCvErOWxtHKJ_RYxrnFuXpwg": "마인드마크",
    "UCmtjEZ9fXPph2RiAvStIjPg": "20th Century Studios Korea",
}
NOT_OFFICIAL_MARK = "공식 유통/배급사 영상이 아님"
OFFICIAL_MARK = "공식 배급사 채널"

TRAILER_KEYWORDS = ["예고", "티저", "trailer", "teaser"]
TRAILER_NEGATIVE = ["리뷰", "리액션", "reaction", "해석", "결말", "쿠키",
                    "비하인드", "메이킹", "making", "인터뷰", "무대인사",
                    "gv", "커밍순", "상영중", "대박기원", "무비토크",
                    "요약", "몰아보기", "정리", "분석", "추천", "순위",
                    "패러디", "더빙", "합성", "모음"]


# ==============================================================================
#  로깅 / 쿼터 (v2와 동일 구조, quota_state.json 공유)
# ==============================================================================
def log(msg: str):
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    try:
        with open(CFG.LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


QUOTA_SPENT = {"units": 0}
QUOTA_STATE = {"date_pt": "", "used": {}}
CURRENT_KEY = {"idx": 0}


def _pt_today() -> str:
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("America/Los_Angeles")).strftime("%Y-%m-%d")
    except Exception:
        return (datetime.utcnow() - timedelta(hours=7)).strftime("%Y-%m-%d")


def key_fp(key: str) -> str:
    return "…" + key[-6:]


def _quota_key_id(idx: int) -> str:
    return f"{idx}:{key_fp(CFG.API_KEYS[idx])}"


def load_quota_state():
    today = _pt_today()
    st = None
    if os.path.exists(CFG.QUOTA_STATE_FILE):
        try:
            with open(CFG.QUOTA_STATE_FILE, "r", encoding="utf-8") as f:
                st = json.load(f)
        except (OSError, json.JSONDecodeError):
            st = None
    if not st or st.get("date_pt") != today:
        st = {"date_pt": today, "used": {}}
    QUOTA_STATE.clear()
    QUOTA_STATE.update(st)
    save_quota_state()
    return QUOTA_STATE


def save_quota_state():
    try:
        with open(CFG.QUOTA_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(QUOTA_STATE, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def spend(units: int):
    QUOTA_SPENT["units"] += units
    if CFG.API_KEYS:
        kid = _quota_key_id(CURRENT_KEY["idx"])
        QUOTA_STATE.setdefault("used", {})[kid] = \
            QUOTA_STATE.get("used", {}).get(kid, 0) + units
        save_quota_state()


def mark_key_fully_used(idx: int):
    kid = _quota_key_id(idx)
    used = QUOTA_STATE.get("used", {}).get(kid, 0)
    QUOTA_STATE.setdefault("used", {})[kid] = max(used, CFG.DAILY_QUOTA_PER_KEY)
    save_quota_state()


def log_quota_summary(title: str):
    log(f"{title} — 키별 쿼터(추정, PT {QUOTA_STATE.get('date_pt','?')} 기준):")
    total_remain = 0
    for i, k in enumerate(CFG.API_KEYS):
        used = QUOTA_STATE.get("used", {}).get(_quota_key_id(i), 0)
        remain = max(0, CFG.DAILY_QUOTA_PER_KEY - used)
        total_remain += remain
        log(f"    키{i+1}({key_fp(k)}): 사용 ~{used:,} / 잔여 ~{remain:,}")
    log(f"    → 전체 잔여 ~{total_remain:,}유닛 ≈ 영화 {total_remain // 102}편 처리 가능")


# ==============================================================================
#  예외 & API 래퍼 (v2와 동일)
# ==============================================================================
class QuotaExceeded(Exception):
    pass


class AllKeysExhausted(Exception):
    pass


def execute_with_retry(request, what: str, cost: int = 1):
    for attempt in range(CFG.MAX_RETRIES + 1):
        try:
            resp = request.execute()
            spend(cost)
            return resp
        except HttpError as e:
            status = int(getattr(e.resp, "status", 0) or 0)
            reason = _http_reason(e)
            if reason in ("quotaExceeded", "dailyLimitExceeded"):
                raise QuotaExceeded(f"{what}: 일일 쿼터 초과({reason})")
            if status == 429 or reason in ("rateLimitExceeded", "userRateLimitExceeded",
                                           "RESOURCE_EXHAUSTED", "RATE_LIMIT_EXCEEDED"):
                if attempt < 2:
                    wait = CFG.RETRY_BACKOFF_SEC * (2 ** attempt)
                    log(f"  · {what} 429/레이트리밋({reason or status}) → {wait:.0f}s 후 재시도")
                    time.sleep(wait)
                    continue
                raise QuotaExceeded(f"{what}: 429 지속 → 쿼터 소진으로 간주({reason or status})")
            if reason in ("backendError", "internalError") or 500 <= status < 600:
                if attempt < CFG.MAX_RETRIES:
                    wait = CFG.RETRY_BACKOFF_SEC * (2 ** attempt)
                    log(f"  · {what} 일시오류({reason or status}) → {wait:.0f}s 후 재시도")
                    time.sleep(wait)
                    continue
            raise
    raise RuntimeError(f"{what}: 재시도 초과")


def _http_reason(e: "HttpError") -> str:
    try:
        data = json.loads(e.content.decode("utf-8"))
        err = data.get("error", {})
        if isinstance(err, dict):
            errors = err.get("errors") or []
            if errors and errors[0].get("reason"):
                return errors[0]["reason"]
            for d in err.get("details") or []:
                if isinstance(d, dict) and d.get("reason"):
                    return d["reason"]
            return err.get("status", "") or ""
    except Exception:
        pass
    return ""


# ==============================================================================
#  키 로테이션
# ==============================================================================
def usable_key_indices(cp: dict) -> list:
    today = _pt_today()
    exhausted = cp.get("exhausted_keys", {})
    return [i for i, k in enumerate(CFG.API_KEYS) if exhausted.get(key_fp(k)) != today]


def mark_key_exhausted(cp: dict, idx: int):
    cp.setdefault("exhausted_keys", {})[key_fp(CFG.API_KEYS[idx])] = _pt_today()
    save_checkpoint(cp)


def build_youtube(api_key: str):
    return build("youtube", "v3", developerKey=api_key, cache_discovery=False)


def rotate_key(cp: dict, cur_idx: int):
    mark_key_exhausted(cp, cur_idx)
    mark_key_fully_used(cur_idx)
    usable = usable_key_indices(cp)
    if not usable:
        raise AllKeysExhausted("등록된 모든 키의 오늘 쿼터가 소진되었습니다.")
    nxt = usable[0]
    CURRENT_KEY["idx"] = nxt
    log(f"  ↻ API 키 교체: {key_fp(CFG.API_KEYS[cur_idx])} → {key_fp(CFG.API_KEYS[nxt])} "
        f"(남은 키 {len(usable)}개)")
    return nxt, build_youtube(CFG.API_KEYS[nxt])


# ==============================================================================
#  날짜/제목/매칭 (v2와 동일 로직)
# ==============================================================================
def parse_date(s: str):
    s = (str(s) or "").strip()
    digits = re.sub(r"\D", "", s)
    if len(digits) >= 8:
        try:
            return datetime.strptime(digits[:8], "%Y%m%d")
        except ValueError:
            return None
    return None


def normalize_title(t: str) -> str:
    t = (t or "").lower()
    return re.sub(r"[^0-9a-z가-힣]", "", t)


def _main_title(title: str) -> str:
    return re.split(r"\s*[:：]\s*", title.strip(), maxsplit=1)[0].strip()


def score_video(norm_movie: str, video: dict, release_dt, raw_movie: str = "") -> float:
    raw_title = video["title"]
    norm_video = normalize_title(raw_title)
    low = raw_title.lower()

    pos = norm_video.find(norm_movie)
    if pos < 0:
        return -1
    if raw_movie and not raw_movie.strip()[-1:].isdigit():
        if re.search(re.escape(raw_movie.strip()) + r"\d", raw_title):
            return -1
    elif not raw_movie:
        after = norm_video[pos + len(norm_movie): pos + len(norm_movie) + 1]
        if after.isdigit() and not norm_movie[-1:].isdigit():
            return -1
    if not any(k in low for k in TRAILER_KEYWORDS):
        return -1
    if any(k in low for k in TRAILER_NEGATIVE):
        return -1

    bracket_hit = boundary_hit = False
    if raw_movie:
        pat = re.escape(raw_movie.strip())
        if re.search(rf"[\[<【(《〈「『]\s*{pat}\s*[\]>】)》〉」』]", raw_title):
            bracket_hit = True
        if re.search(rf"(?:^|[^0-9A-Za-z가-힣]){pat}(?:[^0-9A-Za-z가-힣]|$)", raw_title):
            boundary_hit = True
    # 비공식 검색은 오매칭 위험이 커서 v2보다 엄격하게:
    # 3글자 이하 제목은 독립 단어/괄호 표기로 확인될 때만 인정
    if len(norm_movie) <= 3 and not (bracket_hit or boundary_hit):
        return -1

    score = 1.0
    if bracket_hit:
        score += 1.5
    elif boundary_hit:
        score += 0.7
    if "메인 예고" in raw_title or "메인예고" in norm_video:
        score += 3
    elif "예고" in raw_title:
        score += 2
    if "공식" in raw_title or "official" in low:
        score += 1
    if "티저" in raw_title or "teaser" in low:
        score += 0.5

    pub_dt = parse_date(video.get("published_at", "")[:10].replace("-", ""))
    if release_dt and pub_dt:
        days = abs((pub_dt - release_dt).days)
        if days > CFG.RELEASE_DATE_WINDOW_MONTHS * 31:
            return -1
        score += max(0.0, 1.0 - days / 400.0)
    elif release_dt and not pub_dt:
        score -= 0.5   # 게시일을 모르면 감점(윈도우 검증 불가)
    return score


# ==============================================================================
#  검색 (채널 제한 없음, 100유닛) + 조회수 랭킹(1유닛)
# ==============================================================================
def search_candidates(youtube, title: str, release: str):
    """search.list로 예고편 후보 수집. 채널 제한 없음.
    전체 제목으로 없으면 같은 응답에서 본제(콜론 앞)로 재평가(추가 비용 0)."""
    req = youtube.search().list(
        part="snippet", q=f"{title} 예고편", type="video",
        maxResults=CFG.SEARCH_MAX_RESULTS, order="relevance",
        regionCode="KR", relevanceLanguage="ko",
    )
    resp = execute_with_retry(req, f"search.list('{title}')", cost=100)
    release_dt = parse_date(release)
    items = []
    for it in resp.get("items", []):
        sn = it.get("snippet", {})
        vid = it.get("id", {}).get("videoId")
        if not vid:
            continue
        items.append({"video_id": vid, "title": sn.get("title", ""),
                      "published_at": sn.get("publishedAt", ""),
                      "channel_id": sn.get("channelId", ""),
                      "channel_title": sn.get("channelTitle", "")})

    def _score_all(query_title):
        norm = normalize_title(query_title)
        out = []
        if not norm:
            return out
        for v in items:
            s = score_video(norm, v, release_dt, raw_movie=query_title)
            if s > 0:
                out.append({**v, "score": s})
        return out

    cands = _score_all(title)
    if not cands:
        main = _main_title(title)
        if main and main != title and normalize_title(main) != normalize_title(title):
            cands = _score_all(main)
    cands.sort(key=lambda c: -c["score"])
    return cands[:CFG.CANDIDATE_POOL]


def rank_by_views(youtube, cands: list):
    if not cands:
        return cands
    ids = ",".join(c["video_id"] for c in cands[:50])
    req = youtube.videos().list(part="statistics", id=ids)
    resp = execute_with_retry(req, "videos.list(조회수)", cost=1)
    views = {}
    for it in resp.get("items", []):
        stats_ = it.get("statistics", {}) or {}
        views[it["id"]] = int(stats_.get("viewCount", 0) or 0)
    for c in cands:
        c["view_count"] = views.get(c["video_id"], 0)
    cands.sort(key=lambda c: (-c["view_count"], -c["score"]))
    return cands


# ==============================================================================
#  댓글 수집 (v2와 동일)
# ==============================================================================
def fetch_top_comments(youtube, video_id: str, max_n: int):
    comments, page_token = [], None
    try:
        while len(comments) < max_n:
            req = youtube.commentThreads().list(
                part="snippet", videoId=video_id,
                maxResults=min(100, max_n - len(comments)),
                order=CFG.COMMENT_ORDER, textFormat=CFG.COMMENT_TEXT_FORMAT,
                pageToken=page_token,
            )
            resp = execute_with_retry(req, f"commentThreads.list({video_id})", cost=1)
            for item in resp.get("items", []):
                c = item["snippet"]["topLevelComment"]["snippet"]
                comments.append({
                    "comment_id": item["snippet"]["topLevelComment"]["id"],
                    "author": c.get("authorDisplayName", ""),
                    "text": c.get("textDisplay", ""),
                    "like_count": c.get("likeCount", 0),
                    "published_at": c.get("publishedAt", ""),
                    "reply_count": item["snippet"].get("totalReplyCount", 0),
                })
                if len(comments) >= max_n:
                    break
            page_token = resp.get("nextPageToken")
            if not page_token:
                break
        return comments, "ok"
    except HttpError as e:
        reason = _http_reason(e)
        if reason == "commentsDisabled":
            return [], "comments_disabled"
        if reason in ("videoNotFound", "forbidden"):
            return [], f"unavailable:{reason}"
        log(f"  ! 댓글 수집 오류({video_id}): {reason or e}")
        return comments, f"error:{reason or 'unknown'}"


# ==============================================================================
#  입력 로드 / 체크포인트
# ==============================================================================
def _cell_to_datestr(v) -> str:
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%Y%m%d")
    if isinstance(v, float):
        v = int(v)
    return str(v).strip()


def load_release_dates():
    """엑셀에서 index(0-based 데이터 행 순서) → (영화명, 개봉일) 매핑 생성."""
    if not os.path.exists(CFG.MOVIES_XLSX):
        sys.exit(f"엑셀을 찾을 수 없습니다: {CFG.MOVIES_XLSX}")
    try:
        from openpyxl import load_workbook
    except ImportError:
        sys.exit("pip install openpyxl 필요")
    wb = load_workbook(CFG.MOVIES_XLSX, read_only=True, data_only=True)
    ws = wb.worksheets[0]
    rows_iter = ws.iter_rows(values_only=True)
    header = [str(h).strip() if h is not None else "" for h in next(rows_iter)]
    out = []
    for r in rows_iter:
        if r is None or all(v is None for v in r):
            continue
        d = dict(zip(header, r))
        out.append((str(d.get(CFG.COL_TITLE) or "").strip(),
                    _cell_to_datestr(d.get(CFG.COL_RELEASE))))
    wb.close()
    return out


def load_unmatched():
    if not os.path.exists(CFG.INPUT_UNMATCHED):
        sys.exit(f"unmatched_movies.csv를 찾을 수 없습니다: {CFG.INPUT_UNMATCHED}\n"
                 f"→ v2 크롤러를 먼저 실행해 미매칭 목록을 생성하세요.")
    with open(CFG.INPUT_UNMATCHED, "r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    seen, uniq, skipped = set(), [], 0
    for r in rows:
        reason = (r.get("사유") or "").strip()
        if any(reason.startswith(p) for p in CFG.SKIP_REASON_PREFIXES):
            skipped += 1
            continue
        key = r.get("index")
        if key in seen:
            continue
        seen.add(key)
        uniq.append(r)
    log(f"unmatched 로드: 전체 {len(rows)}행 → 처리 대상 {len(uniq)}편 "
        f"(제외 키워드 {skipped}건, 중복 제거 후)")
    return uniq


def load_checkpoint():
    if os.path.exists(CFG.CHECKPOINT_FILE):
        with open(CFG.CHECKPOINT_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"done_indices": [], "exhausted_keys": {}}


def save_checkpoint(cp):
    with open(CFG.CHECKPOINT_FILE, "w", encoding="utf-8") as f:
        json.dump(cp, f, ensure_ascii=False, indent=2)


def record_still_unmatched(idx, title, distributor, reason):
    new_file = not os.path.exists(CFG.STILL_UNMATCHED_CSV)
    with open(CFG.STILL_UNMATCHED_CSV, "a", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(["index", "영화명", "배급사", "사유"])
        w.writerow([idx, title, distributor, reason])


# ==============================================================================
#  메인
# ==============================================================================
OUTPUT_FIELDS = ["movie_title", "distributor", "video_id", "video_title",
                 "channel_title", "video_url", "video_view_count", "video_rank",
                 "official_status", "comment_id", "author", "text",
                 "like_count", "published_at", "reply_count"]


def main():
    log("=" * 70)
    log("미매칭 영화 크롤러 시작 (비공식 채널 허용, search.list 100유닛/편)")

    if not CFG.API_KEYS:
        sys.exit("API 키가 없습니다. (v2와 같은 순서로 입력하세요)")
    log(f"등록된 API 키: {len(CFG.API_KEYS)}개")

    cp = load_checkpoint()
    load_quota_state()
    log_quota_summary("시작 시점")
    usable = usable_key_indices(cp)
    if not usable:
        sys.exit("모든 키가 오늘(태평양시) 쿼터 소진 상태입니다. 리셋 후 재실행하세요.")
    key_idx = usable[0]
    CURRENT_KEY["idx"] = key_idx
    youtube = build_youtube(CFG.API_KEYS[key_idx])
    log(f"시작 키: {key_fp(CFG.API_KEYS[key_idx])}")

    excel_rows = load_release_dates()
    targets_all = load_unmatched()
    limit = CFG.TEST_LIMIT if CFG.TEST_LIMIT else len(targets_all)
    targets = targets_all[CFG.START_INDEX: CFG.START_INDEX + limit]
    done = set(cp.get("done_indices", []))
    remaining = sum(1 for r in targets if int(r["index"]) not in done)
    log(f"처리 대상: {len(targets)}편 중 미완료 {remaining}편 "
        f"(예상 쿼터 ~{remaining * 102:,}유닛)")

    new_file = not os.path.exists(CFG.OUTPUT_CSV)
    out = open(CFG.OUTPUT_CSV, "a", encoding="utf-8-sig", newline="")
    writer = csv.DictWriter(out, fieldnames=OUTPUT_FIELDS)
    if new_file:
        writer.writeheader()

    stats = {"movies": 0, "found": 0, "comments": 0, "not_found": 0,
             "official_hits": 0}
    stopped_reason = None
    try:
        for row in targets:
            idx = int(row["index"])
            if idx in done:
                continue
            title = (row.get(CFG.COL_TITLE) or "").strip()
            distributor = (row.get(CFG.COL_DISTRIBUTOR) or "").strip()
            if not title:
                continue

            # 엑셀에서 개봉일 조회 (index 정합성 확인)
            release = ""
            if 0 <= idx < len(excel_rows):
                ex_title, ex_release = excel_rows[idx]
                if normalize_title(ex_title) == normalize_title(title):
                    release = ex_release
                else:
                    log(f"  ! index {idx} 영화명 불일치(엑셀:'{ex_title}' vs CSV:'{title}')"
                        f" → 개봉일 필터 없이 진행")
            stats["movies"] += 1
            log(f"[{idx+1}] {title}  (배급사: {distributor})")

            while True:
                try:
                    cands = search_candidates(youtube, title, release)   # 100유닛
                    if not cands:
                        stats["not_found"] += 1
                        record_still_unmatched(idx, title, distributor, "검색에서도 예고편 미발견")
                        log(f"    ! 검색에서도 미발견 → unmatched_after_search.csv 기록")
                        break

                    cands = rank_by_views(youtube, cands)                # 1유닛

                    collected = False
                    for rank, c in enumerate(cands[:CFG.MAX_CANDIDATE_TRIES], start=1):
                        official = OFFICIAL_CHANNEL_IDS.get(c["channel_id"])
                        status_mark = OFFICIAL_MARK if official else NOT_OFFICIAL_MARK
                        tag = "공식" if official else "비공식"
                        if rank == 1:
                            log(f"    ▶ 조회수 1위[{tag}]: {c['title']} "
                                f"/ {c['channel_title']} ({c['view_count']:,}회)")
                        else:
                            log(f"    ↪ 차순위 {rank}위[{tag}]로 대체: {c['title']} "
                                f"/ {c['channel_title']}")
                        comments, status = fetch_top_comments(youtube, c["video_id"],
                                                              CFG.COMMENTS_PER_VIDEO)
                        if status == "ok":
                            for cm in comments:
                                writer.writerow({
                                    "movie_title": title, "distributor": distributor,
                                    "video_id": c["video_id"], "video_title": c["title"],
                                    "channel_title": c["channel_title"],
                                    "video_url": f"https://www.youtube.com/watch?v={c['video_id']}",
                                    "video_view_count": c["view_count"],
                                    "video_rank": rank,
                                    "official_status": status_mark,
                                    **cm,
                                })
                            out.flush()
                            stats["found"] += 1
                            stats["comments"] += len(comments)
                            if official:
                                stats["official_hits"] += 1
                            collected = True
                            break
                        log(f"    · 댓글 수집 불가({status}) → 다음 후보 시도")

                    if not collected:
                        stats["not_found"] += 1
                        record_still_unmatched(idx, title, distributor,
                                               f"후보 {min(len(cands), CFG.MAX_CANDIDATE_TRIES)}개 모두 댓글 수집 불가")
                    break

                except QuotaExceeded as e:
                    log(f"  ! 쿼터 소진: {e}")
                    key_idx, youtube = rotate_key(cp, key_idx)
                    log(f"  ↻ 같은 영화를 새 키로 재시도: {title} (검색 100유닛 재소모)")

            done.add(idx)
            cp["done_indices"] = sorted(done)
            save_checkpoint(cp)
            time.sleep(CFG.SLEEP_BETWEEN_MOVIES)

    except AllKeysExhausted as e:
        stopped_reason = str(e)
        log(f"모든 키 소진으로 안전 중단: {e}")
        log("→ 쿼터 리셋(한국시간 오후 4~5시) 이후 재실행하면 이어서 진행됩니다.")
    except KeyboardInterrupt:
        stopped_reason = "사용자 중단"
        log("사용자 중단. 체크포인트 저장됨 → 재실행 시 이어서 진행.")
    finally:
        out.close()

    log("-" * 70)
    log(f"이번 실행: 영화 {stats['movies']} / 수집 성공 {stats['found']} "
        f"(그중 공식 채널 {stats['official_hits']}) / 댓글 {stats['comments']} / "
        f"미발견 {stats['not_found']}")
    log(f"이번 실행 쿼터: ~{QUOTA_SPENT['units']:,}유닛")
    log_quota_summary("종료 시점")
    log(f"결과 CSV: {CFG.OUTPUT_CSV}")
    log(f"미발견 목록: {CFG.STILL_UNMATCHED_CSV}")
    if stopped_reason:
        log(f"중단 사유: {stopped_reason}")
    log("종료")


if __name__ == "__main__":
    main()
"""
03 · 기본 차트 생성 (제작비 계열 제외)

각 차트는 원본 PDF 빈 박스의 '캡션 위 여백' 크기(pt)에 정확히 맞춰 만든다.
배경색을 박스 색(#F3F7F4)과 동일하게 지정해 얹었을 때 경계가 보이지 않게 한다.
숫자는 02에서 뽑은 좌표를 보고 계산한 값으로, 박스별 가용 영역 크기다.
"""
import re
from collections import Counter

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

from config import (DATA, BG, MAIN, SUB, ACC, LIGHT, MUTED,
                    newfig, newfigs, clean, save)

df = pd.read_pickle(f"{DATA}/main.pkl")   # 537편
raw = pd.read_pickle(f"{DATA}/raw.pkl")   # 688편 원본

genre_counts = df['주장르'].value_counts()
BIG = genre_counts[genre_counts >= 8].index.tolist()   # 표본 8편 이상 장르만

# ---------- p9: 연도별 개봉 편수 (560x351) ----------
yr = df['개봉연도'].value_counts().sort_index()
fig, ax = newfig(560, 351)
ax.bar(yr.index.astype(int).astype(str), yr.values, color=MAIN)
for i, v in enumerate(yr.values):
    ax.text(i, v + 0.7, str(v), ha='center', fontsize=7.5, color=MUTED)
ax.set_ylabel("편수", fontsize=8.5, color=MUTED)
plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
clean(ax)
save(fig, "p9_yearly_count")

# ---------- p9: 변수 자료형과 결측률 (630x230) ----------
dtypes = {"숫자형": 0, "문자형": 0, "날짜형": 0}
for c in raw.columns:
    if c in ('개봉일_dt', '개봉연도', '개봉월'):
        continue
    if c in ('개봉일', '제작연도'):
        dtypes["날짜형"] += 1
    elif pd.api.types.is_numeric_dtype(raw[c]):
        dtypes["숫자형"] += 1
    else:
        dtypes["문자형"] += 1
miss = (raw.drop(columns=['개봉일_dt', '개봉연도', '개봉월']).isna().mean() * 100)
bins = [("결측 0%", (miss == 0).sum()), ("0–5%", ((miss > 0) & (miss <= 5)).sum()),
        ("5–10%", ((miss > 5) & (miss <= 10)).sum()), ("10%+", (miss > 10).sum())]
fig, axes = newfigs(630, 230, 2)
a = axes[0]
a.bar(list(dtypes.keys()), list(dtypes.values()), color=[MAIN, SUB, LIGHT])
for i, v in enumerate(dtypes.values()):
    a.text(i, v + 0.6, str(v), ha='center', fontsize=8.5, color=MUTED)
a.set_title("자료형 구분 (총 51개 변수)", fontsize=9, color=MUTED)
clean(a)
a = axes[1]
a.bar([b[0] for b in bins], [b[1] for b in bins], color=SUB)
for i, v in enumerate([b[1] for b in bins]):
    a.text(i, v + 0.6, str(v), ha='center', fontsize=8.5, color=MUTED)
a.set_title("변수별 결측률 분포", fontsize=9, color=MUTED)
clean(a)
plt.tight_layout()
save(fig, "p9_dtype_missing")

# ---------- p10: 매출액 분포 (720x321 each) ----------
rev = df['전국매출액'].dropna()
fig, ax = newfig(720, 321)
ax.hist(rev / 1e8, bins=45, color=MAIN)
ax.axvline(rev.mean() / 1e8, color=ACC, ls='--', lw=1.4, label=f"평균 {rev.mean()/1e8:.0f}억")
ax.axvline(rev.median() / 1e8, color=SUB, ls='--', lw=1.4, label=f"중앙값 {rev.median()/1e8:.0f}억")
ax.set_xlabel("전국매출액 (억원)", fontsize=8.5, color=MUTED)
ax.legend(fontsize=8, frameon=False)
clean(ax)
save(fig, "p10_rev_raw")

fig, ax = newfig(720, 321)
ax.hist(np.log10(rev[rev > 0]), bins=45, color=SUB)
ax.set_xlabel("log10(전국매출액)", fontsize=8.5, color=MUTED)
clean(ax)
save(fig, "p10_rev_log")

# ---------- p14: 제외 사유별 건수 (520x291) ----------
fig, ax = newfig(520, 291)
labels = ["기간 외", "비장편", "비극장용", "재개봉", "중복", "매칭실패"]
vals = [64, 84, 3, 0, 0, 0]
ax.bar(labels, vals, color=[MAIN, MAIN, MAIN, "#D9D9D3", "#D9D9D3", "#D9D9D3"])
for i, v in enumerate(vals):
    ax.text(i, v + 1.5, str(v) if v else "0", ha='center', fontsize=8.5,
            color=MUTED if v else "#B0B0AA")
ax.set_ylabel("편수", fontsize=8.5, color=MUTED)
plt.setp(ax.get_xticklabels(), rotation=30, ha='right')
clean(ax)
save(fig, "p14_exclusion")

# ---------- p19: 4 wide panels (720x141) ----------
ym = df.groupby('개봉연도').agg(관객=('전국관객수', 'sum'), 매출=('전국매출액', 'sum')).reset_index()
fig, ax = newfig(720, 141)
ax.plot(ym['개봉연도'], ym['관객'] / 1e6, marker='o', ms=3, color=MAIN, lw=1.5)
ax2 = ax.twinx(); ax2.set_facecolor(BG)
ax2.plot(ym['개봉연도'], ym['매출'] / 1e8, marker='s', ms=3, color=ACC, lw=1.5)
ax.set_ylabel("관객(백만)", fontsize=7.5, color=MAIN)
ax2.set_ylabel("매출(억)", fontsize=7.5, color=ACC)
clean(ax, 7.5); ax2.tick_params(labelsize=7.5, colors=MUTED)
ax2.spines[['top']].set_visible(False)
save(fig, "p19_market")

fig, ax = newfig(720, 141)
ax.boxplot([df[df['개봉월'] == m]['전국관객수'] / 1e4 for m in range(1, 13)],
           tick_labels=[f"{m}" for m in range(1, 13)], showfliers=False,
           patch_artist=True, boxprops=dict(facecolor=MAIN, color=MAIN),
           medianprops=dict(color=ACC), whiskerprops=dict(color="#9AA5A0"),
           capprops=dict(color="#9AA5A0"))
ax.set_ylabel("관객(만)", fontsize=7.5, color=MUTED)
ax.set_xlabel("개봉 월", fontsize=7.5, color=MUTED)
clean(ax, 7.5)
save(fig, "p19_month")

sub = df[df['주장르'].isin(BIG)]
order = sub.groupby('주장르')['전국매출액'].median().sort_values(ascending=False).index
fig, ax = newfig(720, 141)
ax.boxplot([sub[sub['주장르'] == g]['전국매출액'] / 1e8 for g in order],
           tick_labels=list(order), showfliers=False, patch_artist=True,
           boxprops=dict(facecolor=LIGHT, color=SUB), medianprops=dict(color=ACC),
           whiskerprops=dict(color="#9AA5A0"), capprops=dict(color="#9AA5A0"))
ax.set_ylabel("매출(억)", fontsize=7.5, color=MUTED)
plt.setp(ax.get_xticklabels(), rotation=30, ha='right', fontsize=7)
clean(ax, 7.5)
save(fig, "p19_genre_box")

top6 = df['주장르'].value_counts().head(6).index.tolist()
df['장르그룹'] = df['주장르'].apply(lambda g: g if g in top6 else '기타')
piv = df.pivot_table(index='개봉연도', columns='장르그룹', values='전국관객수', aggfunc='sum', fill_value=0)
piv = piv.div(piv.sum(axis=1), axis=0)
fig, ax = newfig(720, 141)
bottom = np.zeros(len(piv))
for c, col in zip(plt.cm.Greens(np.linspace(.35, .9, len(piv.columns))), piv.columns):
    ax.bar(piv.index.astype(int).astype(str), piv[col], bottom=bottom, color=c, label=col)
    bottom += piv[col].values
ax.set_ylabel("점유율", fontsize=7.5, color=MUTED)
ax.legend(fontsize=6, ncol=4, frameon=False, loc='lower center', bbox_to_anchor=(.5, -.62))
plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=7)
clean(ax, 7.5)
save(fig, "p19_genre_share")

# ---------- p20: 코로나 구간 (1010x331) ----------
fig, ax = newfig(1010, 331)
ax2 = ax.twinx(); ax2.set_facecolor(BG)
ax.plot(ym['개봉연도'], ym['관객'] / 1e6, marker='o', color=MAIN, lw=2, label="총 관객수(백만명)")
ax2.plot(ym['개봉연도'], ym['매출'] / 1e8, marker='s', color=ACC, lw=2, label="총 매출액(억원)")
ax.axvspan(2020, 2021, color=LIGHT, alpha=.45)
ax.text(2020.5, ax.get_ylim()[1] * .93, "코로나19", ha='center', fontsize=9, color=MAIN)
ax.set_ylabel("총 관객수 (백만명)", fontsize=9, color=MAIN)
ax2.set_ylabel("총 매출액 (억원)", fontsize=9, color=ACC)
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
ax.legend(h1 + h2, l1 + l2, fontsize=8.5, frameon=False, loc='lower left')
clean(ax, 9); ax2.tick_params(labelsize=9, colors=MUTED); ax2.spines[['top']].set_visible(False)
save(fig, "p20_covid")

# ---------- p21: 키워드 상/하위 각각 (720x310) ----------
STOP = set("""된다 되는데 되고 시작된다 알게 새로운 시작한다 시작하는데 어느 자신의 에게 같은 있을까 된 되어 되며
하는데 하게 되면 한다 하지만 그리고 그런데 위해 위한 대한 대해 하는 한편 이후 통해 있는 있다 라는 그녀 그의
사람 자신 모든 이제 결국 것을 것이 무엇 어떤 다시 모두 함께 세상 인생 우리 서로 하나 순간 상황 사실
만난 만나 없는 않은 않고 없이 하고 당시 최고 최대 가장 지금 여기 그때 이곳 그러나 마침내 점점 조금씩
이런 저런 아니 아니라 않는다 않게 된다는 한다는 있는데 없다 있던 있고 없고 였던 이었다 하며 그러던
어느날 마치 무슨 자신이 자신을 이들 그들 누구 누군가 언제 어디 어디서 무엇을 무엇이 한다면 하면서
하기 하려 하려는 되는 되지 진짜 정말 완전히 아주 그와 각자 해도 영화""".split())
tok = lambda t: [w for w in re.findall(r'[가-힣]{2,}', str(t)) if w not in STOP]
q1, q3 = df['전국매출액'].quantile([.25, .75])
top, bot = df[df['전국매출액'] >= q3], df[df['전국매출액'] <= q1]
tw = Counter([w for t in top['줄거리'] for w in tok(t)])
bw = Counter([w for t in bot['줄거리'] for w in tok(t)])
tt, bt = sum(tw.values()), sum(bw.values())

def distinct(a, ta, b, tb, n=12):
    s = {w: (c / ta) / ((b.get(w, 0) + .5) / tb) for w, c in a.items() if c >= 4}
    return sorted(s.items(), key=lambda x: -x[1])[:n]

for data, name, color, title in [
        (distinct(tw, tt, bw, bt), "p21_kw_top", MAIN, f"매출 상위 25% (n={len(top)})"),
        (distinct(bw, bt, tw, tt), "p21_kw_bot", ACC, f"매출 하위 25% (n={len(bot)})")]:
    words, sc = zip(*data[::-1])
    fig, ax = newfig(720, 310)
    ax.barh(words, sc, color=color)
    ax.set_xlabel("상대빈도 배수 (반대 집단 대비)", fontsize=8.5, color=MUTED)
    ax.set_title(title, fontsize=9.5, color=MUTED)
    clean(ax, 8.5)
    save(fig, name)

# ---------- p22: 배급사별 성과 (720x186) ----------
dc = df['배급사'].value_counts()
bd = dc[dc >= 8].index.tolist()
sd = df[df['배급사'].isin(bd)]
od = sd.groupby('배급사')['전국관객수'].median().sort_values(ascending=False).index
short = lambda s: re.sub(r'\(주\)|주식회사|㈜|\(유\)', '', str(s)).strip()[:11]
fig, ax = newfig(720, 186)
ax.boxplot([sd[sd['배급사'] == g]['전국관객수'] / 1e4 for g in od],
           tick_labels=[short(g) for g in od], showfliers=False, patch_artist=True, vert=True,
           boxprops=dict(facecolor=LIGHT, color=SUB), medianprops=dict(color=ACC),
           whiskerprops=dict(color="#9AA5A0"), capprops=dict(color="#9AA5A0"))
ax.set_ylabel("관객(만명)", fontsize=7.5, color=MUTED)
plt.setp(ax.get_xticklabels(), rotation=35, ha='right', fontsize=6.5)
clean(ax, 7.5)
save(fig, "p22_distributor")

# ---------- p22: 감독·배우 (1240x150, 2 panel) ----------
d = df.dropna(subset=['감독']).sort_values('개봉일_dt').copy()
d['과거'] = [d[(d['감독'] == r['감독']) & (d['개봉일_dt'] < r['개봉일_dt'])]['전국관객수'].mean()
             for _, r in d.iterrows()]
dd = d.dropna(subset=['과거'])
a = df.dropna(subset=['배우']).sort_values('개봉일_dt').copy()
a['주연'] = a['배우'].astype(str).str.split('|').str[0].str.strip()
a['과거'] = [a[(a['주연'] == r['주연']) & (a['개봉일_dt'] < r['개봉일_dt'])]['전국관객수'].mean()
             for _, r in a.iterrows()]
aa = a.dropna(subset=['과거'])
fig, axes = newfigs(1240, 150, 2)
for ax, data, lab, col in [(axes[0], dd, "감독", MAIN), (axes[1], aa, "주연배우", ACC)]:
    rho, _ = stats.spearmanr(data['과거'], data['전국관객수'])
    ax.scatter(data['과거'] / 1e4, data['전국관객수'] / 1e4, s=9, alpha=.5, color=col)
    z = np.polyfit(np.log10(data['과거'] + 1), np.log10(data['전국관객수'] + 1), 1)
    xs = np.linspace(max(data['과거'].min(), 1), data['과거'].max(), 60)
    ax.plot(xs / 1e4, 10 ** (z[0] * np.log10(xs) + z[1]) / 1e4, color="#444", lw=1.2)
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_title(f"{lab}  ρ={rho:.2f}  (n={len(data)})", fontsize=8.5, color=MUTED)
    ax.set_xlabel("개봉 이전 평균 관객수(만, log)", fontsize=7, color=MUTED)
    ax.set_ylabel("신작 관객(만)", fontsize=7, color=MUTED)
    clean(ax, 7)
plt.tight_layout()
save(fig, "p22_people")

# ---------- p23: 집단별 매출 (1010x351) ----------
fig, ax = newfig(1010, 351)
ax.boxplot([sub[sub['주장르'] == g]['전국매출액'] / 1e8 for g in order],
           tick_labels=list(order), showfliers=False, patch_artist=True,
           boxprops=dict(facecolor=LIGHT, color=SUB), medianprops=dict(color=ACC),
           whiskerprops=dict(color="#9AA5A0"), capprops=dict(color="#9AA5A0"))
ax.set_ylabel("전국매출액 (억원)", fontsize=9, color=MUTED)
ax.set_title("장르 기준 · 제작비 구간은 데이터 미보유", fontsize=8.5, color="#9A9A94")
plt.setp(ax.get_xticklabels(), rotation=25, ha='right', fontsize=8.5)
clean(ax, 8.5)
save(fig, "p23_group_box")

# ---------- p26: 3 panels (446x316) ----------
rs = df.dropna(subset=['naver_평점', 'naver_평가건수'])
r1, _ = stats.spearmanr(rs['naver_평점'], rs['전국관객수'])
r2, _ = stats.spearmanr(rs['naver_평가건수'], rs['전국관객수'])
fig, axes = newfigs(446, 316, 2, vertical=True)
axes[0].scatter(rs['naver_평점'], rs['전국관객수'] / 1e4, s=6, alpha=.45, color=MAIN)
axes[0].set_yscale('log'); axes[0].set_xlabel("네이버 평점", fontsize=7, color=MUTED)
axes[0].set_title(f"평점 ρ={r1:.2f}", fontsize=8, color=MUTED)
axes[1].scatter(rs['naver_평가건수'], rs['전국관객수'] / 1e4, s=6, alpha=.45, color=ACC)
axes[1].set_xscale('log'); axes[1].set_yscale('log')
axes[1].set_xlabel("평가건수(log)", fontsize=7, color=MUTED)
axes[1].set_title(f"평가건수 ρ={r2:.2f}", fontsize=8, color=MUTED)
for ax in axes:
    ax.set_ylabel("관객(만)", fontsize=7, color=MUTED); clean(ax, 6.5)
plt.tight_layout()
save(fig, "p26_rating")

v = df.dropna(subset=['1일차_관객수', '7일차_관객수'])
v = v[v['1일차_관객수'] > 0].copy()
v['배수'] = v['7일차_관객수'] / v['1일차_관객수']
med = v[v['주장르'].isin(BIG)].groupby('주장르')['배수'].median().sort_values(ascending=False)
fig, ax = newfig(446, 316)
ax.bar(med.index, med.values, color=MAIN)
for i, val in enumerate(med.values):
    ax.text(i, val + .012, f"{val:.2f}", ha='center', fontsize=6.5, color=MUTED)
ax.set_ylabel("7일차 ÷ 1일차 (중앙값)", fontsize=7.5, color=MUTED)
ax.set_title("※ 일별 10일치 한계로 1→7일차 배수로 대체", fontsize=6.8, color="#9A9A94")
plt.setp(ax.get_xticklabels(), rotation=40, ha='right', fontsize=6.8)
clean(ax, 7)
save(fig, "p26_retention")

vc = [f"{i}일차_관객수" for i in range(1, 11)]
sc_ = [f"{i}일차_상영횟수" for i in range(1, 11)]
df['누적관'] = df[vc].sum(axis=1); df['누적상'] = df[sc_].sum(axis=1)
v2 = df[df['누적상'] > 0].copy(); v2['회차당'] = v2['누적관'] / v2['누적상']
med2 = v2[v2['주장르'].isin(BIG)].groupby('주장르')['회차당'].median().sort_values(ascending=False)
fig, ax = newfig(446, 316)
ax.bar(med2.index, med2.values, color=SUB)
for i, val in enumerate(med2.values):
    ax.text(i, val + .5, f"{val:.0f}", ha='center', fontsize=6.5, color=MUTED)
ax.set_ylabel("회차당 관객수 (명)", fontsize=7.5, color=MUTED)
ax.set_title("개봉 10일 누적 기준", fontsize=6.8, color="#9A9A94")
plt.setp(ax.get_xticklabels(), rotation=40, ha='right', fontsize=6.8)
clean(ax, 7)
save(fig, "p26_perscreen")

# ---------- p27: 2축 위험 지도 (860x371) ----------
gs = df[df['주장르'].isin(BIG)].groupby('주장르')['전국관객수'].agg(n='count', med='median', sd='std')
gs['cv'] = gs['sd'] / gs['med']
fig, ax = newfig(860, 371)
ax.scatter(gs['cv'], gs['med'] / 1e4, s=gs['n'] * 7, color=LIGHT, edgecolor=MAIN, lw=1.3, alpha=.85)
for nm, r in gs.iterrows():
    ax.annotate(nm, (r['cv'], r['med'] / 1e4), fontsize=8, color="#333",
                xytext=(5, 4), textcoords='offset points')
ax.axvline(gs['cv'].median(), color="#B8C4BD", ls='--', lw=1)
ax.axhline((gs['med'] / 1e4).median(), color="#B8C4BD", ls='--', lw=1)
ax.set_xlabel("성과 편차 (변동계수 CV)", fontsize=8.5, color=MUTED)
ax.set_ylabel("집단 성과 중앙값 (관객수, 만명)", fontsize=8.5, color=MUTED)
clean(ax, 8.5)
save(fig, "p27_riskmap")

# ---------- p29 #1: 장르별 매출액 분포 (446x360) ----------
fig, ax = newfig(446, 360)
ax.boxplot([sub[sub['주장르'] == g]['전국매출액'] / 1e8 for g in order],
           tick_labels=list(order), showfliers=False, patch_artist=True,
           boxprops=dict(facecolor=LIGHT, color=SUB), medianprops=dict(color=ACC),
           whiskerprops=dict(color="#9AA5A0"), capprops=dict(color="#9AA5A0"))
ax.set_ylabel("매출(억원)", fontsize=7.5, color=MUTED)
ax.set_title("장르마다 성과 수준과 편차가 다르다", fontsize=8, color=MAIN)
plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=6.8)
clean(ax, 7)
save(fig, "p29_genre")




# ══ p7 : '한일' 3칸 (차트가 아니라 텍스트 블록) ═══════════
def textblock(name, wpt, hpt, lines):
    fig = plt.figure(figsize=(wpt / 72, hpt / 72))
    fig.patch.set_facecolor(BG)
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis('off'); ax.set_facecolor(BG)
    y = 0.94
    for kind, txt in lines:
        if kind == 'h':
            ax.text(0.04, y, txt, fontsize=9.5, color=MAIN, weight='bold',
                    va='top', transform=ax.transAxes)
            y -= 0.13
        else:
            ax.text(0.06, y, "\u00b7 " + txt, fontsize=8.6, color="#333", va='top',
                    transform=ax.transAxes, linespacing=1.5)
            y -= 0.135 * (1 + txt.count("\n"))
    fig.savefig(f"fit/{name}.png", dpi=200, facecolor=BG, edgecolor='none')
    plt.close(fig); print("  ", name)


textblock("p7_collect", 446, 265, [
    ('h', "수집 소스 4종"),
    ('b', "KOBIS \u2014 관객수·매출액·스크린·상영횟수\n  (일별 1~10일차 포함)"),
    ('b', "KMDb \u2014 시놉시스·장르·상영시간·등급"),
    ('b', "관객평가 \u2014 CGV·네이버 평점 및 평가건수"),
    ('b', "제작비·BEP \u2014 별도 공유시트로 수집"),
    ('h', "결과"),
    ('b', "688편 × 51개 변수 확보"),
])

textblock("p7_analyze", 446, 265, [
    ('h', "분석 도구"),
    ('b', "분포 왜도 확인 후 로그 변환 판단"),
    ('b', "스피어만 상관 \u2014 감독·배우 이력, 평점, 제작비"),
    ('b', "카이제곱 \u2014 제작비 구간별 BEP 달성률"),
    ('b', "변동계수(CV) 기반 2축 유형 분류"),
    ('h', "시점 통제"),
    ('b', "과거 성과는 개봉일 이전 작품만 사용"),
])

textblock("p7_clean", 446, 265, [
    ('h', "정제 기준"),
    ('b', "2015\u20132024년 개봉작만 (-64편)"),
    ('b', "장편 극영화만, 애니·다큐 제외 (-84편)"),
    ('b', "극장용만 (-3편)"),
    ('h', "결과"),
    ('b', "최종 537편 확정 (원본의 78.1%)"),
    ('h', "결측 점검"),
    ('b', "평점 결측 16편 \u2014 무작위 아님"),
])

print("\n기본 차트 생성 완료")
